﻿
namespace Adventure_StaffApplicationMenu
{
    partial class Delete_Customer_Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Custorder_foodPrice = new System.Windows.Forms.TextBox();
            this.txt_Custorder_firstName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.remove_Order = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.choose_Order = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_Custorder_foodName = new System.Windows.Forms.TextBox();
            this.txt_Custorder_foodType = new System.Windows.Forms.TextBox();
            this.txt_Custorder_surName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_Custorder_ID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txt_Custorder_foodPrice
            // 
            this.txt_Custorder_foodPrice.Location = new System.Drawing.Point(338, 270);
            this.txt_Custorder_foodPrice.Name = "txt_Custorder_foodPrice";
            this.txt_Custorder_foodPrice.Size = new System.Drawing.Size(100, 23);
            this.txt_Custorder_foodPrice.TabIndex = 139;
            // 
            // txt_Custorder_firstName
            // 
            this.txt_Custorder_firstName.Location = new System.Drawing.Point(235, 183);
            this.txt_Custorder_firstName.Name = "txt_Custorder_firstName";
            this.txt_Custorder_firstName.Size = new System.Drawing.Size(120, 23);
            this.txt_Custorder_firstName.TabIndex = 133;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(268, 273);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 132;
            this.label6.Text = "Order Cost:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(260, 215);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 15);
            this.label5.TabIndex = 131;
            this.label5.Text = "Food Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(112, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 15);
            this.label3.TabIndex = 130;
            this.label3.Text = "Customer Firstname:";
            // 
            // remove_Order
            // 
            this.remove_Order.Location = new System.Drawing.Point(415, 311);
            this.remove_Order.Name = "remove_Order";
            this.remove_Order.Size = new System.Drawing.Size(75, 23);
            this.remove_Order.TabIndex = 129;
            this.remove_Order.Text = "Delete";
            this.remove_Order.UseVisualStyleBackColor = true;
            this.remove_Order.Click += new System.EventHandler(this.remove_Order_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(268, 311);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 128;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // choose_Order
            // 
            this.choose_Order.FormattingEnabled = true;
            this.choose_Order.Location = new System.Drawing.Point(312, 116);
            this.choose_Order.Name = "choose_Order";
            this.choose_Order.Size = new System.Drawing.Size(120, 23);
            this.choose_Order.TabIndex = 127;
            this.choose_Order.Text = "Select an Order";
            this.choose_Order.SelectedIndexChanged += new System.EventHandler(this.choose_Order_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(326, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 21);
            this.label2.TabIndex = 126;
            this.label2.Text = "Order Info";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(312, 58);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(124, 21);
            this.Label4.TabIndex = 124;
            this.Label4.Text = "Remove a Order";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(235, 17);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 123;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(265, 244);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 140;
            this.label7.Text = "Food  Type:";
            // 
            // txt_Custorder_foodName
            // 
            this.txt_Custorder_foodName.Location = new System.Drawing.Point(338, 212);
            this.txt_Custorder_foodName.Name = "txt_Custorder_foodName";
            this.txt_Custorder_foodName.Size = new System.Drawing.Size(184, 23);
            this.txt_Custorder_foodName.TabIndex = 141;
            // 
            // txt_Custorder_foodType
            // 
            this.txt_Custorder_foodType.Location = new System.Drawing.Point(338, 241);
            this.txt_Custorder_foodType.Name = "txt_Custorder_foodType";
            this.txt_Custorder_foodType.Size = new System.Drawing.Size(184, 23);
            this.txt_Custorder_foodType.TabIndex = 142;
            // 
            // txt_Custorder_surName
            // 
            this.txt_Custorder_surName.Location = new System.Drawing.Point(479, 183);
            this.txt_Custorder_surName.Name = "txt_Custorder_surName";
            this.txt_Custorder_surName.Size = new System.Drawing.Size(120, 23);
            this.txt_Custorder_surName.TabIndex = 144;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(361, 186);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 15);
            this.label8.TabIndex = 143;
            this.label8.Text = "Customer Surname:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(266, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 15);
            this.label9.TabIndex = 145;
            this.label9.Text = "Order ID:";
            // 
            // txt_Custorder_ID
            // 
            this.txt_Custorder_ID.Location = new System.Drawing.Point(326, 148);
            this.txt_Custorder_ID.Name = "txt_Custorder_ID";
            this.txt_Custorder_ID.Size = new System.Drawing.Size(100, 23);
            this.txt_Custorder_ID.TabIndex = 146;
            // 
            // Delete_Customer_Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 376);
            this.Controls.Add(this.txt_Custorder_ID);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_Custorder_surName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_Custorder_foodType);
            this.Controls.Add(this.txt_Custorder_foodName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_Custorder_foodPrice);
            this.Controls.Add(this.txt_Custorder_firstName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.remove_Order);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.choose_Order);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label1);
            this.Name = "Delete_Customer_Order";
            this.Text = "Delete_Customer_Order";
            this.Load += new System.EventHandler(this.Delete_Customer_Order_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Custorder_foodPrice;
        private System.Windows.Forms.TextBox txt_Custorder_firstName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button remove_Order;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.ComboBox choose_Order;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_Custorder_foodName;
        private System.Windows.Forms.TextBox txt_Custorder_foodType;
        private System.Windows.Forms.TextBox txt_Custorder_surName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_Custorder_ID;
    }
}