﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Adventure_StaffApplicationMenu
{
    public partial class Customer_List_Form : Form
    {
        // These properties help connect to
        // or use data from the database
        private string conn;
        MySqlConnection connect;
        MySqlCommand cmd;
        MySqlDataAdapter myAdapter;
        DataTable table;

        // Gets and sets the datasource
        public DataTable DataSource { get; internal set; }

        public Customer_List_Form()
        {
            // Initializes form
            InitializeComponent();
        }

        // Database Connection code
        private void db_connection()
        {
            // Connects to the database
            try
            {
                conn = "Server=localhost;Database=escape;Uid=root;Pwd=root;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        // Return Button
        private void Return_Button_Click(object sender, EventArgs e)
        {
            // Closes the customer list form
            Close();
        }

        // Customer List Form Load
        private void Customer_List_Form_Load(object sender, EventArgs e)
        {
            //Loads the search data function
            searchData("");
        }

        // Search Data
        public void searchData(string valueToSearch)
        {
            // Searches for the search data
            // Connects to the database
            db_connection();
            // The query searches for specific data by input
            string query = "SELECT * FROM customer WHERE CONCAT(customer_id, customer_firstname, customer_surname) like '%" + valueToSearch + "%'";
            // New command to set the query
            cmd = new MySqlCommand(query, connect);
            // New adapter for the database command
            myAdapter = new MySqlDataAdapter(cmd);
            // New table for the database
            table = new DataTable();
            // Adapter fills the table
            myAdapter.Fill(table);
            // Places the data in the specified table.
            dataCustomerList.DataSource = table;
        }

        // Search Button
        private void BTN_SEARCH_Click(object sender, EventArgs e)
        {
            // Gets input from text box
            string valueToSearch = txtCustomerList.Text.ToString();
            // the search data equals the input
            searchData(valueToSearch);
        }

        // Alphabetical Order button
        private void alpha_Click(object sender, EventArgs e)
        {
            // Sets command text to alphabetizise table
            cmd.CommandText = "SELECT * FROM customer ORDER BY customer_firstname ASC";
            // Connects the command
            cmd.Connection = connect;
            // New adapter for the database command
            myAdapter = new MySqlDataAdapter(cmd);
            // New table for the database
            table = new DataTable();
            // Adapter fills the table
            myAdapter.Fill(table);
            // Places the data in the specified table
            dataCustomerList.DataSource = table;
        }

        // Delete Customer button
        private void delete_Click(object sender, EventArgs e)
        {
            // Makes the Delete Customer form a variable
            var DeleteCustomer = new Delete_Customer();
            // Displays the form
            DeleteCustomer.Show();
        }

        // Reload Table button
        private void table_Reload_Click(object sender, EventArgs e)
        {
            // Refreshes the table
            // Opens the database connection
            db_connection();
            // Creates a new database command
            MySqlCommand cmd = new MySqlCommand();
            // Sets the query in the database command,
            // the query is a stored procedure
            cmd.CommandText = "CALL `Customer List`()";
            // Sets the connection for the database command
            cmd.Connection = connect;
            // Creates a new adapter to hold the output from the query
            myAdapter = new MySqlDataAdapter();
            // Sets the MySql command for the adapter
            myAdapter.SelectCommand = cmd;
            // Creates a new dataset
            DataSet ds = new DataSet();
            // Adapter fills the table
            myAdapter.Fill(ds);
            // Places the data in the specified table
            dataCustomerList.DataSource = ds.Tables[0];
        }

        // Customer History Button
        private void BTN_cust_History_Click(object sender, EventArgs e)
        {
            // Makes the Customer History Form a variable
            var custHistory = new Customer_HistoryList();
            // Displays the form
            custHistory.Show();
        }
    }
}
