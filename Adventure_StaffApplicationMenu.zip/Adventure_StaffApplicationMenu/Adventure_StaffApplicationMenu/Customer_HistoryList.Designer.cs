﻿
namespace Adventure_StaffApplicationMenu
{
    partial class Customer_HistoryList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Return_Button = new System.Windows.Forms.Button();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.data_CustomerHistory = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data_CustomerHistory)).BeginInit();
            this.SuspendLayout();
            // 
            // Return_Button
            // 
            this.Return_Button.Location = new System.Drawing.Point(12, 12);
            this.Return_Button.Name = "Return_Button";
            this.Return_Button.Size = new System.Drawing.Size(163, 23);
            this.Return_Button.TabIndex = 20;
            this.Return_Button.Text = "Return to Customer List";
            this.Return_Button.UseVisualStyleBackColor = true;
            this.Return_Button.Click += new System.EventHandler(this.Return_Button_Click);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(324, 104);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(132, 21);
            this.Label4.TabIndex = 19;
            this.Label4.Text = "Customer History";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(233, 51);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 18;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.data_CustomerHistory);
            this.groupBox1.Location = new System.Drawing.Point(12, 128);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(776, 310);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customer History";
            // 
            // data_CustomerHistory
            // 
            this.data_CustomerHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_CustomerHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.data_CustomerHistory.Location = new System.Drawing.Point(3, 19);
            this.data_CustomerHistory.Name = "data_CustomerHistory";
            this.data_CustomerHistory.RowTemplate.Height = 25;
            this.data_CustomerHistory.Size = new System.Drawing.Size(770, 288);
            this.data_CustomerHistory.TabIndex = 1;
            // 
            // Customer_HistoryList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Return_Button);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label1);
            this.Name = "Customer_HistoryList";
            this.Text = "Customer_HistoryList";
            this.Load += new System.EventHandler(this.Customer_HistoryList_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.data_CustomerHistory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button Return_Button;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView data_CustomerHistory;
    }
}