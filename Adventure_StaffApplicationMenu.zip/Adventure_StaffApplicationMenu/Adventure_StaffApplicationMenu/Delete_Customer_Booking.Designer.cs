﻿
namespace Adventure_StaffApplicationMenu
{
    partial class Delete_Customer_Booking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Custbooking_totAdults = new System.Windows.Forms.TextBox();
            this.txt_Custbooking_escName = new System.Windows.Forms.TextBox();
            this.txt_Custbooking_firstName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.remove_Booking = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.choose_Booking = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_Custbooking_totChild = new System.Windows.Forms.TextBox();
            this.txt_Custbooking_totPrice = new System.Windows.Forms.TextBox();
            this.txt_Custbooking_ID = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_Custbooking_surName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_Custbooking_totAdults
            // 
            this.txt_Custbooking_totAdults.Location = new System.Drawing.Point(238, 228);
            this.txt_Custbooking_totAdults.Name = "txt_Custbooking_totAdults";
            this.txt_Custbooking_totAdults.Size = new System.Drawing.Size(100, 23);
            this.txt_Custbooking_totAdults.TabIndex = 118;
            // 
            // txt_Custbooking_escName
            // 
            this.txt_Custbooking_escName.Location = new System.Drawing.Point(238, 199);
            this.txt_Custbooking_escName.Name = "txt_Custbooking_escName";
            this.txt_Custbooking_escName.Size = new System.Drawing.Size(184, 23);
            this.txt_Custbooking_escName.TabIndex = 117;
            // 
            // txt_Custbooking_firstName
            // 
            this.txt_Custbooking_firstName.Location = new System.Drawing.Point(238, 170);
            this.txt_Custbooking_firstName.Name = "txt_Custbooking_firstName";
            this.txt_Custbooking_firstName.Size = new System.Drawing.Size(126, 23);
            this.txt_Custbooking_firstName.TabIndex = 116;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(438, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 15);
            this.label6.TabIndex = 113;
            this.label6.Text = "Total Price:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(122, 202);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 15);
            this.label5.TabIndex = 112;
            this.label5.Text = "Escaperoom Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(115, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 15);
            this.label3.TabIndex = 111;
            this.label3.Text = "Customer Firstname:";
            // 
            // remove_Booking
            // 
            this.remove_Booking.Location = new System.Drawing.Point(419, 279);
            this.remove_Booking.Name = "remove_Booking";
            this.remove_Booking.Size = new System.Drawing.Size(75, 23);
            this.remove_Booking.TabIndex = 110;
            this.remove_Booking.Text = "Delete";
            this.remove_Booking.UseVisualStyleBackColor = true;
            this.remove_Booking.Click += new System.EventHandler(this.remove_Booking_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(289, 279);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 109;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // choose_Booking
            // 
            this.choose_Booking.FormattingEnabled = true;
            this.choose_Booking.Location = new System.Drawing.Point(326, 112);
            this.choose_Booking.Name = "choose_Booking";
            this.choose_Booking.Size = new System.Drawing.Size(121, 23);
            this.choose_Booking.TabIndex = 108;
            this.choose_Booking.Text = "Choose a Customer Name";
            this.choose_Booking.SelectedIndexChanged += new System.EventHandler(this.choose_Booking_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(332, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 21);
            this.label2.TabIndex = 107;
            this.label2.Text = "Booking Info";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(313, 58);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(140, 21);
            this.Label4.TabIndex = 105;
            this.Label4.Text = "Remove a booking";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(236, 17);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 104;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(419, 231);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 15);
            this.label7.TabIndex = 119;
            this.label7.Text = "Total Children:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(160, 231);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 15);
            this.label8.TabIndex = 120;
            this.label8.Text = "Total Adults:";
            // 
            // txt_Custbooking_totChild
            // 
            this.txt_Custbooking_totChild.Location = new System.Drawing.Point(508, 228);
            this.txt_Custbooking_totChild.Name = "txt_Custbooking_totChild";
            this.txt_Custbooking_totChild.Size = new System.Drawing.Size(100, 23);
            this.txt_Custbooking_totChild.TabIndex = 121;
            // 
            // txt_Custbooking_totPrice
            // 
            this.txt_Custbooking_totPrice.Location = new System.Drawing.Point(508, 199);
            this.txt_Custbooking_totPrice.Name = "txt_Custbooking_totPrice";
            this.txt_Custbooking_totPrice.Size = new System.Drawing.Size(100, 23);
            this.txt_Custbooking_totPrice.TabIndex = 122;
            // 
            // txt_Custbooking_ID
            // 
            this.txt_Custbooking_ID.Location = new System.Drawing.Point(377, 141);
            this.txt_Custbooking_ID.Name = "txt_Custbooking_ID";
            this.txt_Custbooking_ID.Size = new System.Drawing.Size(100, 23);
            this.txt_Custbooking_ID.TabIndex = 123;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(303, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 15);
            this.label9.TabIndex = 124;
            this.label9.Text = "Booking ID:";
            // 
            // txt_Custbooking_surName
            // 
            this.txt_Custbooking_surName.Location = new System.Drawing.Point(508, 170);
            this.txt_Custbooking_surName.Name = "txt_Custbooking_surName";
            this.txt_Custbooking_surName.Size = new System.Drawing.Size(126, 23);
            this.txt_Custbooking_surName.TabIndex = 126;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(390, 173);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 15);
            this.label10.TabIndex = 125;
            this.label10.Text = "Customer Surname:";
            // 
            // Delete_Customer_Booking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 325);
            this.Controls.Add(this.txt_Custbooking_surName);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_Custbooking_ID);
            this.Controls.Add(this.txt_Custbooking_totPrice);
            this.Controls.Add(this.txt_Custbooking_totChild);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_Custbooking_totAdults);
            this.Controls.Add(this.txt_Custbooking_escName);
            this.Controls.Add(this.txt_Custbooking_firstName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.remove_Booking);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.choose_Booking);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label1);
            this.Name = "Delete_Customer_Booking";
            this.Text = "Delete_Customer_Booking";
            this.Load += new System.EventHandler(this.Delete_Customer_Booking_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_Custbooking_totAdults;
        private System.Windows.Forms.TextBox txt_Custbooking_escName;
        private System.Windows.Forms.TextBox txt_Custbooking_firstName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button remove_Booking;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.ComboBox choose_Booking;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_Custbooking_totChild;
        private System.Windows.Forms.TextBox txt_Custbooking_totPrice;
        private System.Windows.Forms.TextBox txt_Custbooking_ID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_Custbooking_surName;
        private System.Windows.Forms.Label label10;
    }
}