﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Adventure_StaffApplicationMenu
{

    public partial class Staff_Menu_Form : Form
    {

        public Staff_Menu_Form()
        {
            // Initializes form
            InitializeComponent();
        }

        // Customer Bookings button
        private void CustBookings_Button_Click(object sender, EventArgs e)
        {
            // Makes the Customer bookings form a variable
            var CustBookings = new Customer_Bookings_Form();
            // Displays the form
            CustBookings.Show();
        }

        // Customer List button
        private void CustList_Button_Click(object sender, EventArgs e)
        {
            // Makes the Customer list form a variable
            var CustList = new Customer_List_Form();
            // Displays the form
            CustList.Show();
        }

        // Exit button
        private void Exit_Button_Click(object sender, EventArgs e)
        {
            // Closes the application
            Close();
        }

        private void Staff_Menu_Form_Load(object sender, EventArgs e)
        {
            // Nothing here
        }

        // Storage List button
        private void StorList_Button_Click(object sender, EventArgs e)
        {
            // Makes the Storage List form a variable
            var StorList = new Storage_List_Form();
            // Displays the form
            StorList.Show();
        }

        // Staff List button
        private void StaffList_Button_Click(object sender, EventArgs e)
        {
            // Makes the staff list form a variable
            var StaffList = new Staff_List_Form();
            // Displays the form
            StaffList.Show();
        }

        // Customer Orders button
        private void CustOrders_Button_Click(object sender, EventArgs e)
        {
            // Makes the customer orders form a variable
            var CustOrders = new Customer_Orders_Form();
            // Displays the form
            CustOrders.Show();
        }
    }
}
