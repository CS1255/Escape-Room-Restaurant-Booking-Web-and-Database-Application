﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Adventure_StaffApplicationMenu
{
    public partial class Delete_Customer_Order : Form
    {
        // These properties help connect to
        // or use data from the database
        private string conn;
        private MySqlConnection connect;
        MySqlCommand cmd;
        private MySqlDataAdapter orderAdapter;
        private DataTable orderTable;
        public Delete_Customer_Order()
        {
            // Initializes form
            InitializeComponent();
        }

        // Database Connection code
        private void db_connection()
        {
            // Connects to the database
            try
            {
                conn = "Server=localhost;Database=escape;Uid=root;Pwd=root;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        // Delete Customer Order Load
        private void Delete_Customer_Order_Load(object sender, EventArgs e)
        {
            // Selects the specific order
            // Connects to the database
            db_connection();
            // Creates a new database command
            MySqlCommand cmd = new MySqlCommand();
            // Sets the query in the database command
            cmd.CommandText = "SELECT custOrder_id, custOrder_firstName, custOrder_surname, custOrder_foodName, custOrder_foodType, custOrder_foodPrice from orders_list";
            // Sets the connection for the database command
            cmd.Connection = connect;
            // Create a new adapter to hold the data from the query
            orderAdapter = new MySqlDataAdapter();
            // Set the MySql command for the adapter
            orderAdapter.SelectCommand = cmd;
            // Creates a new datatable
            orderTable = new DataTable();
            // Adapter fills the table
            orderAdapter.Fill(orderTable);
            // Dropdown gets the data from the table
            choose_Order.DataSource = orderTable;
            // Displays the specified data
            choose_Order.DisplayMember = "custOrder_firstName";
            // Identifies each item by id
            choose_Order.ValueMember = "custOrder_id";
            // close connection
            connect.Close();
        }

        // Remove Orders button
        private void remove_Order_Click(object sender, EventArgs e)
        {
            // Removes the order
            // Connects to the database
            db_connection();
            // Query deletes order from text input
            string query = "DELETE from orders_list where custOrder_id = '" + txt_Custorder_ID.Text + "'";
            // New command to activate the query
            cmd = new MySqlCommand(query, connect);
            // Prompt message
            MessageBox.Show("Delete Successful!");
            // Executes the command
            cmd.ExecuteNonQuery();
        }

        // Choose order selected index
        private void choose_Order_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Changes data output
            // Connectes to the database
            db_connection();
            // New command to read the query
            cmd = new MySqlCommand("SELECT * FROM orders_list where custOrder_firstName ='" + choose_Order.Text + "'", connect);
            // Executes the command
            cmd.ExecuteNonQuery();
            // Data reader for booking
            MySqlDataReader orderReader;
            // Command activates reader
            orderReader = cmd.ExecuteReader();
            // While statement for reader
            // Reads the input
            // Converts query column into strings
            // Textbox equals string
            while (orderReader.Read())
            {
                string orderID = (string)orderReader["custOrder_id"].ToString();
                txt_Custorder_ID.Text = orderID;

                string custFirstName = (string)orderReader["custOrder_firstName"].ToString();
                txt_Custorder_firstName.Text = custFirstName;

                string custSurName = (string)orderReader["custOrder_surName"].ToString();
                txt_Custorder_surName.Text = custSurName;

                string foodName = (string)orderReader["custOrder_foodName"].ToString();
                txt_Custorder_foodName.Text = foodName;

                string foodType = (string)orderReader["custOrder_foodType"].ToString();
                txt_Custorder_foodType.Text = foodType;

                string foodPrice = (string)orderReader["custOrder_foodPrice"].ToString();
                txt_Custorder_foodPrice.Text = foodPrice;
            }
        }

        // Cancel button
        private void cancel_Click(object sender, EventArgs e)
        {
            // Closes form
            Close();
        }
    }
}
