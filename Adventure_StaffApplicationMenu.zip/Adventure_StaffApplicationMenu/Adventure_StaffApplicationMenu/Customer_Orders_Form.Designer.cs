﻿
namespace Adventure_StaffApplicationMenu
{
    partial class Customer_Orders_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTN_DELETE = new System.Windows.Forms.Button();
            this.Return_Button = new System.Windows.Forms.Button();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.dataCustomerOrder = new System.Windows.Forms.DataGridView();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.table_Reload = new System.Windows.Forms.Button();
            this.GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataCustomerOrder)).BeginInit();
            this.SuspendLayout();
            // 
            // BTN_DELETE
            // 
            this.BTN_DELETE.Location = new System.Drawing.Point(224, 124);
            this.BTN_DELETE.Name = "BTN_DELETE";
            this.BTN_DELETE.Size = new System.Drawing.Size(171, 23);
            this.BTN_DELETE.TabIndex = 32;
            this.BTN_DELETE.Text = "DELETE Customer Order";
            this.BTN_DELETE.UseVisualStyleBackColor = true;
            this.BTN_DELETE.Click += new System.EventHandler(this.BTN_DELETE_Click);
            // 
            // Return_Button
            // 
            this.Return_Button.Location = new System.Drawing.Point(12, 12);
            this.Return_Button.Name = "Return_Button";
            this.Return_Button.Size = new System.Drawing.Size(124, 23);
            this.Return_Button.TabIndex = 31;
            this.Return_Button.Text = "Return to Options";
            this.Return_Button.UseVisualStyleBackColor = true;
            this.Return_Button.Click += new System.EventHandler(this.Return_Button_Click);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.dataCustomerOrder);
            this.GroupBox1.Location = new System.Drawing.Point(12, 153);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(776, 285);
            this.GroupBox1.TabIndex = 30;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Customer Order Details";
            // 
            // dataCustomerOrder
            // 
            this.dataCustomerOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataCustomerOrder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataCustomerOrder.Location = new System.Drawing.Point(3, 19);
            this.dataCustomerOrder.Name = "dataCustomerOrder";
            this.dataCustomerOrder.RowTemplate.Height = 25;
            this.dataCustomerOrder.Size = new System.Drawing.Size(770, 263);
            this.dataCustomerOrder.TabIndex = 0;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label2.Location = new System.Drawing.Point(319, 93);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(132, 15);
            this.Label2.TabIndex = 29;
            this.Label2.Text = "List of Customer Orders";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(319, 55);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(130, 21);
            this.Label4.TabIndex = 28;
            this.Label4.Text = "Customer Orders";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(224, 12);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 27;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // table_Reload
            // 
            this.table_Reload.Location = new System.Drawing.Point(409, 124);
            this.table_Reload.Name = "table_Reload";
            this.table_Reload.Size = new System.Drawing.Size(95, 23);
            this.table_Reload.TabIndex = 33;
            this.table_Reload.Text = "Reload Table";
            this.table_Reload.UseVisualStyleBackColor = true;
            this.table_Reload.Click += new System.EventHandler(this.table_Reload_Click);
            // 
            // Customer_Orders_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.table_Reload);
            this.Controls.Add(this.BTN_DELETE);
            this.Controls.Add(this.Return_Button);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label1);
            this.Name = "Customer_Orders_Form";
            this.Text = "Customer_Orders_Form";
            this.Load += new System.EventHandler(this.Customer_Orders_Form_Load);
            this.GroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataCustomerOrder)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTN_DELETE;
        internal System.Windows.Forms.Button Return_Button;
        internal System.Windows.Forms.GroupBox GroupBox1;
        private System.Windows.Forms.DataGridView dataCustomerOrder;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Button table_Reload;
    }
}