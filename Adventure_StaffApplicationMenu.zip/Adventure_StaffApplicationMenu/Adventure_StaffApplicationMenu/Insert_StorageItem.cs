﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Adventure_StaffApplicationMenu
{
    public partial class Insert_StorageItem : Form
    {
        // These properties help connect to
        // or use data from the database
        private string conn;
        MySqlConnection connect;
        MySqlCommand cmd;
        public Insert_StorageItem()
        {
            // Initializes form
            InitializeComponent();
        }

        // Database Connection code
        private void db_connection()
        {
            // Connects to the database
            try
            {
                conn = "Server=localhost;Database=escape;Uid=root;Pwd=root;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        // Cancel button
        private void cancel_Click(object sender, EventArgs e)
        {
            // Closes form
            Close();
        }

        // Stock Type selected index
        private void stock_Type_SelectedIndexChanged(object sender, EventArgs e)
        {
            // if statement, if stock type = 0,
            // type is "Asset"
            if (stock_Type.SelectedIndex == 0)
            {
                // Disables the text boxes
                txt_IngredientID.Enabled = false;
                txt_IngredientName.Enabled = false;
                txt_IngredientCost.Enabled = false;
                txt_IngredientStock.Enabled = false;
                txt_IngredientAvail.Enabled = false;
                // Enables the text boxes
                txt_AssetID.Enabled = true;
                txt_AssetName.Enabled = true;
                asset_Status.Enabled = true;
                txt_AssetAvailability.Enabled = true;
            }
            // else if statement, if stock type = 1,
            // type is "ingredient"
            else if (stock_Type.SelectedIndex == 1)
            {
                // Disables the text boxes
                txt_AssetID.Enabled = false;
                txt_AssetName.Enabled = false;
                asset_Status.Enabled = false;
                txt_AssetAvailability.Enabled = false;
                // Enables the text boxes
                txt_IngredientID.Enabled = true;
                txt_IngredientName.Enabled = true;
                txt_IngredientCost.Enabled = true;
                txt_IngredientStock.Enabled = true;
                txt_IngredientAvail.Enabled = true;
            }
        }

        // Add item to data base
        private void add_StockItem_Click(object sender, EventArgs e)
        {
            // if statement, if stock type = 0
            // Insert item in Assets
            if (stock_Type.SelectedIndex == 0)
            {
                // Insert item into assets
                // Connects to database
                db_connection();
                // Query to insert new item
                string query = "INSERT INTO escaperoom_assets(asset_id, asset_name, asset_status, asset_availability)Values('"+ txt_IngredientID.Text + "','" + txt_AssetName.Text + "','" + asset_Status.Text + "','" + txt_AssetAvailability.Text + "')";               
                // Command to activate query
                cmd = new MySqlCommand(query, connect);
                // Prompt message
                MessageBox.Show("Insert Successful!");
                // Execute the command
                cmd.ExecuteNonQuery();
            } 
            // else if statement, if stock type = 1
            // Insert item into ingredients
            else if (stock_Type.SelectedIndex == 1)
            {
                // Insert item into ingredients
                // Connects to database
                db_connection();
                // Query to insert new item
                string query = "INSERT INTO ingredients(ingredients_id, ingredients_name, ingredients_cost, ingredient_stock, ingredient_availability)Values('" + txt_IngredientID.Text + "', '" + txt_IngredientName.Text + "','" + txt_IngredientCost.Text + "','" + txt_IngredientStock.Text + "','" + txt_IngredientAvail.Text + "')";
                // Command to activate query
                cmd = new MySqlCommand(query, connect);
                // Prompt message
                MessageBox.Show("Insert Successful!");
                // Execute the command
                cmd.ExecuteNonQuery();
            }
        }

        // Insert storage item load
        private void Insert_StorageItem_Load(object sender, EventArgs e)
        {
            // Adds as dropdown options for stock type
            stock_Type.Items.Add("Asset");
            stock_Type.Items.Add("Ingredient");
            // Adds as dropdown options for asset status
            asset_Status.Items.Add("Clean");
            asset_Status.Items.Add("Dirty");
        }

        // Asset status selected index
        private void asset_Status_SelectedIndexChanged(object sender, EventArgs e)
        {
            // If statement, if asset status = 0
            // Set asset status to clean
            // Render text as "1" and read only
            if (asset_Status.SelectedIndex == 0)
            {
                txt_AssetAvailability.Text = "1";
                txt_AssetAvailability.ReadOnly = true;
            }
            // else if statement, if asset status = 0
            // Set asset status to dirty
            // Render text as "0" and read only
            else if (asset_Status.SelectedIndex == 1)
            {
                txt_AssetAvailability.Text = "0";
                txt_AssetAvailability.ReadOnly = true;
            }
        }

        // Ingredient stock keypress
        private void txt_IngredientStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Checks if input characters are numbers only.
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                // Only allow numbers.
                e.Handled = true;
            }
        }

        // Ingredient Stock text change
        private void txt_IngredientStock_TextChanged(object sender, EventArgs e)
        {
            // Creates a new integer
            int ingreTotal;
            // creates a new boolean
            // Sets text box as an integer
            bool ingreAvail = Int32.TryParse(txt_IngredientStock.Text, out ingreTotal);
            // if statement, if ingredient total is greater than 0
            // Render text as "1" and read only
            if (ingreTotal > 0)
            {
                txt_IngredientAvail.Text = "1";
                txt_IngredientAvail.ReadOnly = true;
            }
            // else if statement, if ingredient total is greater than 0
            // Render text as "0" and read only
            else if (ingreTotal <= 0)
            {
                txt_IngredientAvail.Text = "0";
                txt_IngredientAvail.ReadOnly = true;
            }
        }

        // Asset id key press
        private void txt_AssetID_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Checks if input characters are numbers only.
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                // Only allow numbers
                e.Handled = true;
            }
        }

        // Ingredient id key press
        private void txt_IngredientID_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Checks if input characters are numbers only.
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                // Only allow numbers
                e.Handled = true;
            }
        }
    }
}
