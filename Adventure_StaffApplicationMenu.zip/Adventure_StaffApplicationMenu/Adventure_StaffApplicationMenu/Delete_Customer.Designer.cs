﻿
namespace Adventure_StaffApplicationMenu
{
    partial class Delete_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.remove_Customer = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.choose_Customer = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_Customer_Firstname = new System.Windows.Forms.TextBox();
            this.txt_Customer_Surname = new System.Windows.Forms.TextBox();
            this.txt_Customer_Email = new System.Windows.Forms.TextBox();
            this.txt_Customer_Phone = new System.Windows.Forms.TextBox();
            this.txt_Customer_Comment = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_Customer_ID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // remove_Customer
            // 
            this.remove_Customer.Location = new System.Drawing.Point(440, 269);
            this.remove_Customer.Name = "remove_Customer";
            this.remove_Customer.Size = new System.Drawing.Size(75, 23);
            this.remove_Customer.TabIndex = 93;
            this.remove_Customer.Text = "Delete";
            this.remove_Customer.UseVisualStyleBackColor = true;
            this.remove_Customer.Click += new System.EventHandler(this.remove_Customer_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(298, 269);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 92;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // choose_Customer
            // 
            this.choose_Customer.FormattingEnabled = true;
            this.choose_Customer.Location = new System.Drawing.Point(311, 112);
            this.choose_Customer.Name = "choose_Customer";
            this.choose_Customer.Size = new System.Drawing.Size(144, 23);
            this.choose_Customer.TabIndex = 91;
            this.choose_Customer.Text = "Choose a Customer";
            this.choose_Customer.SelectedIndexChanged += new System.EventHandler(this.choose_Customer_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(323, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 21);
            this.label2.TabIndex = 82;
            this.label2.Text = "Customer Info";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(313, 58);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(148, 21);
            this.Label4.TabIndex = 80;
            this.Label4.Text = "Remove a customer";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(236, 17);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 79;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(119, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 15);
            this.label3.TabIndex = 94;
            this.label3.Text = "Customer Firstname:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(417, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 15);
            this.label5.TabIndex = 95;
            this.label5.Text = "Customer Surname:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(142, 204);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 15);
            this.label6.TabIndex = 96;
            this.label6.Text = "Customer Email:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(430, 204);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 15);
            this.label7.TabIndex = 97;
            this.label7.Text = "Customer Phone:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(175, 233);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 15);
            this.label8.TabIndex = 98;
            this.label8.Text = "Customer Comment:";
            // 
            // txt_Customer_Firstname
            // 
            this.txt_Customer_Firstname.Location = new System.Drawing.Point(240, 172);
            this.txt_Customer_Firstname.Name = "txt_Customer_Firstname";
            this.txt_Customer_Firstname.Size = new System.Drawing.Size(100, 23);
            this.txt_Customer_Firstname.TabIndex = 99;
            // 
            // txt_Customer_Surname
            // 
            this.txt_Customer_Surname.Location = new System.Drawing.Point(533, 172);
            this.txt_Customer_Surname.Name = "txt_Customer_Surname";
            this.txt_Customer_Surname.Size = new System.Drawing.Size(100, 23);
            this.txt_Customer_Surname.TabIndex = 100;
            // 
            // txt_Customer_Email
            // 
            this.txt_Customer_Email.Location = new System.Drawing.Point(240, 201);
            this.txt_Customer_Email.Name = "txt_Customer_Email";
            this.txt_Customer_Email.Size = new System.Drawing.Size(184, 23);
            this.txt_Customer_Email.TabIndex = 101;
            // 
            // txt_Customer_Phone
            // 
            this.txt_Customer_Phone.Location = new System.Drawing.Point(533, 201);
            this.txt_Customer_Phone.Name = "txt_Customer_Phone";
            this.txt_Customer_Phone.Size = new System.Drawing.Size(100, 23);
            this.txt_Customer_Phone.TabIndex = 102;
            // 
            // txt_Customer_Comment
            // 
            this.txt_Customer_Comment.Location = new System.Drawing.Point(298, 230);
            this.txt_Customer_Comment.Name = "txt_Customer_Comment";
            this.txt_Customer_Comment.Size = new System.Drawing.Size(320, 23);
            this.txt_Customer_Comment.TabIndex = 103;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(279, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 15);
            this.label9.TabIndex = 104;
            this.label9.Text = "Customer ID:";
            // 
            // txt_Customer_ID
            // 
            this.txt_Customer_ID.Location = new System.Drawing.Point(361, 141);
            this.txt_Customer_ID.Name = "txt_Customer_ID";
            this.txt_Customer_ID.Size = new System.Drawing.Size(100, 23);
            this.txt_Customer_ID.TabIndex = 105;
            // 
            // Delete_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 337);
            this.Controls.Add(this.txt_Customer_ID);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_Customer_Comment);
            this.Controls.Add(this.txt_Customer_Phone);
            this.Controls.Add(this.txt_Customer_Email);
            this.Controls.Add(this.txt_Customer_Surname);
            this.Controls.Add(this.txt_Customer_Firstname);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.remove_Customer);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.choose_Customer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label1);
            this.Name = "Delete_Customer";
            this.Text = "Delete_Customer";
            this.Load += new System.EventHandler(this.Delete_Customer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button remove_Customer;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.ComboBox choose_Customer;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_Customer_Firstname;
        private System.Windows.Forms.TextBox txt_Customer_Surname;
        private System.Windows.Forms.TextBox txt_Customer_Email;
        private System.Windows.Forms.TextBox txt_Customer_Phone;
        private System.Windows.Forms.TextBox txt_Customer_Comment;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_Customer_ID;
    }
}