﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Adventure_StaffApplicationMenu
{
    public partial class Delete_Customer : Form
    {
        // These properties help connect to
        // or use data from the database
        private string conn;
        private MySqlConnection connect;
        MySqlCommand cmd;
        private MySqlDataAdapter customerAdapter;
        private DataTable customerTable;
        public Delete_Customer()
        {
            // Initializes form
            InitializeComponent();
        }

        // Database Connection code
        private void db_connection()
        {
            // Connects to the database
            try
            {
                conn = "Server=localhost;Database=escape;Uid=root;Pwd=root;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        // Delete Customer Form Load
        private void Delete_Customer_Load(object sender, EventArgs e)
        {
            // Selects the specific customer
            // Opens the database connection
            db_connection();
            // Created a new database command
            MySqlCommand cmd = new MySqlCommand();
            // Sets the query in the database command
            cmd.CommandText = "SELECT customer_id, customer_firstname, customer_surname, customer_email, customer_phone, customer_comment from customer";
            // Sets the connection for the database command
            cmd.Connection = connect;
            // Create a new adapter to hold the data from the query
            customerAdapter = new MySqlDataAdapter();
            // Set the MySql command for the adapter
            customerAdapter.SelectCommand = cmd;
            // Creates a new datatable
            customerTable = new DataTable();
            // Adapter fills the table
            customerAdapter.Fill(customerTable);
            // Dropdown gets the data from the table
            choose_Customer.DataSource = customerTable;
            // Displays the specified data
            choose_Customer.DisplayMember = "customer_firstname";
            // Identifies each item by id
            choose_Customer.ValueMember = "customer_id";
            // close connection
            connect.Close();
        }

        // Remove Customer button
        private void remove_Customer_Click(object sender, EventArgs e)
        {
            // Removes the customer
            //Connects to the database
            db_connection();
            // Query deletes customer from text input
            string query = "DELETE from customer where customer_id = '" + txt_Customer_ID.Text + "'";
            // New command to activate the query
            cmd = new MySqlCommand(query, connect);
            // Prompt message
            MessageBox.Show("Delete Successful!");
            // Executes the command
            cmd.ExecuteNonQuery();
        }

        // Cancel button
        private void cancel_Click(object sender, EventArgs e)
        {
            // Closes form
            Close();
        }

        // Choose customer selected index
        private void choose_Customer_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Changes data output
            // Connectes to the database
            db_connection();
            // New command to read the query
            cmd = new MySqlCommand("SELECT * FROM customer where customer_firstname ='" + choose_Customer.Text + "'", connect);
            // Executes the command
            cmd.ExecuteNonQuery();
            // Data reader for customer
            MySqlDataReader customerReader;
            // Command activates reader
            customerReader = cmd.ExecuteReader();
            // While statement for reader
            // Reads the input
            // Converts query column into strings
            // Textbox equals string
            while (customerReader.Read())
            {
                string customerID = (string)customerReader["customer_id"].ToString();
                txt_Customer_ID.Text = customerID;

                string customerFirstName = (string)customerReader["customer_firstname"].ToString();
                txt_Customer_Firstname.Text = customerFirstName;

                string customerSurName = (string)customerReader["customer_surname"].ToString();
                txt_Customer_Surname.Text = customerSurName;

                string customerEmail = (string)customerReader["customer_email"].ToString();
                txt_Customer_Email.Text = customerEmail;

                string customerPhone = (string)customerReader["customer_phone"].ToString();
                txt_Customer_Phone.Text = customerPhone;

                string customerComment = (string)customerReader["customer_comment"].ToString();
                txt_Customer_Comment.Text = customerComment;
            }
        }
    }
}
