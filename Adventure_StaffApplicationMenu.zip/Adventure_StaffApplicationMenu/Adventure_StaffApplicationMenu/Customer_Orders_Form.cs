﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Adventure_StaffApplicationMenu
{
    public partial class Customer_Orders_Form : Form
    {
        // These properties help connect to
        // or use data from the database
        private string conn;
        private MySqlConnection connect;
        private MySqlDataAdapter myAdapter;
        public Customer_Orders_Form()
        {
            // Initializes form
            InitializeComponent();
        }

        // Database Connection code
        private void db_connection()
        {
            // Connects to the database
            try
            {
                conn = "Server=localhost;Database=escape;Uid=root;Pwd=root;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        // Reload Table button
        private void table_Reload_Click(object sender, EventArgs e)
        {
            // Refreshes the table
            // Opens the database connection
            db_connection();
            // Creates a new database command
            MySqlCommand cmd = new MySqlCommand();
            // Sets the query in the database command,
            // the query is a stored procedure
            cmd.CommandText = "CALL `Orders List`()";
            // Sets the connection for the database command
            cmd.Connection = connect;
            // Creates a new adapter to hold the output from the query
            myAdapter = new MySqlDataAdapter();
            // Sets the MySql command for the adapter
            myAdapter.SelectCommand = cmd;
            // Creates a new dataset
            DataSet ds = new DataSet();
            // Adapter fills the dataset
            myAdapter.Fill(ds);
            // Places the data in the specified table.
            dataCustomerOrder.DataSource = ds.Tables[0];
        }

        // Order Delete Button
        private void BTN_DELETE_Click(object sender, EventArgs e)
        {
            // Makes Delete Customer Order form a variable
            var DeleteCustOrder = new Delete_Customer_Order();
            // Displays the form
            DeleteCustOrder.Show();
        }

        // Customer Orders Form Load
        private void Customer_Orders_Form_Load(object sender, EventArgs e)
        {
            // Loads the table
            // Opens the database connection
            db_connection();
            // Creates a new database command
            MySqlCommand cmd = new MySqlCommand();
            // Sets the query in the database command,
            // the query is a stored procedure
            cmd.CommandText = "CALL `Orders List`()";
            // Sets the connection for the database command
            cmd.Connection = connect;
            // Create a new adapter to hold the output from the query
            myAdapter = new MySqlDataAdapter();
            // Set the MySql command for the adapter
            myAdapter.SelectCommand = cmd;
            // Creates a new dataset
            DataSet ds = new DataSet();
            // Adapter fills the dataset
            myAdapter.Fill(ds);
            // Places the data in the specified table
            dataCustomerOrder.DataSource = ds.Tables[0];
        }

        // Return button
        private void Return_Button_Click(object sender, EventArgs e)
        {
            // Closes form
            Close();
        }
    }
}
