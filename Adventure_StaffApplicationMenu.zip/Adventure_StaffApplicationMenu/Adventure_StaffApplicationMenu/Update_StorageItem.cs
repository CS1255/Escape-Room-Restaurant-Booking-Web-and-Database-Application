﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Adventure_StaffApplicationMenu
{
    public partial class Update_StorageItem : Form
    {
        // These properties help connect to
        // or use data from the database
        private string conn;
        private MySqlConnection connect;
        MySqlCommand cmd;
        private MySqlDataAdapter assetAdapter;
        private MySqlDataAdapter ingredientAdapter;
        private DataTable assetTable;
        private DataTable ingredientTable;
        public Update_StorageItem()
        {
            // Initializes form
            InitializeComponent();
        }

        // Database Connection code
        private void db_connection()
        {
            // Connects to the database
            try
            {
                conn = "Server=localhost;Database=escape;Uid=root;Pwd=root;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        // stock type selected index
        private void stock_Type_SelectedIndexChanged(object sender, EventArgs e)
        {
            // if statement, if stock type = 0
            // stock type = "Asset"
            if (stock_Type.SelectedIndex == 0)
            {
                // Disable text boxes
                txt_IngredientName.Enabled = false;
                txt_IngredientCost.Enabled = false;
                txt_IngredientStock.Enabled = false;
                txt_IngredientAvail.Enabled = false;
                // Enable text boxes
                txt_AssetName.Enabled = true;
                asset_Status.Enabled = true;
                txt_AssetAvailability.Enabled = true;
            }
            // else if statement, if stock type = 1
            // stock type = "Ingredient"
            else if (stock_Type.SelectedIndex == 1)
            {
                // disable text boxes
                txt_AssetName.Enabled = false;
                asset_Status.Enabled = false;
                txt_AssetAvailability.Enabled = false;
                // Enable text boxes
                txt_IngredientName.Enabled = true;
                txt_IngredientCost.Enabled = true;
                txt_IngredientStock.Enabled = true;
                txt_IngredientAvail.Enabled = true;
            }
        }

        // Update stock item button
        private void update_StockItem_Click(object sender, EventArgs e)
        {
            // if statement, if stock type = 0
            // Update "Asset"
            if (stock_Type.SelectedIndex == 0)
            {
                // Update asset item
                // Connects to the database
                db_connection();
                // Strings for textfields
                string newAssetName = txt_AssetName.Text;
                string newAssetStatus = asset_Status.Text;
                string newAssetAvailability = txt_AssetAvailability.Text;
                // if asset name text box is blank
                // Show message prompt.
                if (newAssetName.Equals(""))
                {
                    MessageBox.Show("Please write a name");
                } 
                // else if asset status text box is blank
                // Show message prompt
                else if (newAssetStatus.Equals(""))
                {
                    MessageBox.Show("Please choose a status");
                } 
                // else if asset availability text box is blank
                // Show message prompt
                else if (newAssetAvailability.Equals(""))
                {
                    MessageBox.Show("Please choose a status");
                } 
                // else
                else
                {
                    // Update query with new information
                    string query = "UPDATE escaperoom_assets SET asset_name = '" + newAssetName + "', asset_status = '" + newAssetStatus + "', asset_availability = '" + newAssetAvailability + "' where asset_name = '" + choose_StockNameOLD.Text + "'";
                    // New command to activate query
                    cmd = new MySqlCommand(query, connect);
                    // Prompt message
                    MessageBox.Show("Update Successful!");
                    // Execute the command
                    cmd.ExecuteNonQuery();
                }
            }
            // else if statement, if stock type = 1
            // Update "Ingredient"
            else if (stock_Type.SelectedIndex == 1)
            {
                // Update ingredient item
                // Connects to the database
                db_connection();
                // Strings for textfields
                string newIngreName = txt_IngredientName.Text;
                string newIngreCost = txt_IngredientCost.Text;
                string newIngreStock = txt_IngredientStock.Text;
                string newIngreAvail = txt_IngredientAvail.Text;
                // if ingredient name text box is blank
                // Show message prompt.
                if (newIngreName.Equals(""))
                {
                    MessageBox.Show("Please write a name");
                }
                // else if ingredient cost text box is blank
                // Show message prompt
                else if (newIngreCost.Equals(""))
                {
                    MessageBox.Show("Please input ingredient cost");
                }
                // else if ingredient stock text box is blank
                // Show message prompt
                else if (newIngreStock.Equals("")){
                    MessageBox.Show("Please input a stock number");
                }
                // else if ingredient availability text box is blank
                // Show message prompt
                else if (newIngreAvail.Equals(""))
                {
                    MessageBox.Show("Please input a stock number");
                } 
                // else
                else
                {
                    // Update query with new information
                    string query = "UPDATE ingredients SET ingredients_name = '" + newIngreName + "', ingredient_stock = '" + newIngreStock + "', ingredients_cost = '" + newIngreCost + "', ingredient_availability = '" + newIngreAvail + "' where ingredients_name = '" + choose_StockNameOLD.Text + "'";
                    // New command to activate query
                    cmd = new MySqlCommand(query, connect);
                    // Prompt message
                    MessageBox.Show("Update Successful!");
                    // Execute the command
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Cancel button
        private void cancel_Click(object sender, EventArgs e)
        {
            // Close form
            Close();
        }

        // Update storage item load
        private void Update_StorageItem_Load(object sender, EventArgs e)
        {
            // Add items to dropdown option
            stock_Type.Items.Add("Asset");
            stock_Type.Items.Add("Ingredient");
            // Add items to dropdown option
            choose_StockTypeOLD.Items.Add("Asset");
            choose_StockTypeOLD.Items.Add("Ingredient");
            // Add items to dropdown option
            asset_Status.Items.Add("Clean");
            asset_Status.Items.Add("Dirty");
        }

        // choose stock type selected index
        private void choose_StockTypeOLD_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Selects the old stock type
            // Connects to the database
            db_connection();
            // if statement, if stock type = 0
            // stock type = "Asset"
            if (choose_StockTypeOLD.SelectedIndex == 0)
            {
                // Disables the text boxes
                txt_StockTotal_OLD.Enabled = false;
                txt_StockCost_OLD.Enabled = false;
                // Enables this text box
                txt_StockStatus_OLD.Enabled = true;
                // Creates a new database command
                MySqlCommand cmd = new MySqlCommand();
                // Sets the query in the database command
                cmd.CommandText = "SELECT asset_id, asset_name, asset_status FROM escaperoom_assets";
                // Sets the connection for the database command
                cmd.Connection = connect;
                // Creates new data adapter to hold data from query
                assetAdapter = new MySqlDataAdapter();
                // Sets the MySql command for the adapter
                assetAdapter.SelectCommand = cmd;
                // Creates a new datatable
                assetTable = new DataTable();
                // Adapter fills the table
                assetAdapter.Fill(assetTable);
                // Dropdown gets the data from the table
                choose_StockNameOLD.DataSource = assetTable;
                // Displays the specified data
                choose_StockNameOLD.DisplayMember = "asset_name";
                // Identifies each item by id
                choose_StockNameOLD.ValueMember = "asset_id"; 
                // close connection
                connect.Close();
            }
            // else if statement, if stock type = 1
            // stock type = "Ingredients"
            else if (choose_StockTypeOLD.SelectedIndex == 1)
            {
                // Enables the text boxes
                txt_StockTotal_OLD.Enabled = true;
                txt_StockCost_OLD.Enabled = true;
                // Disables this text box
                txt_StockStatus_OLD.Enabled = false;
                // Creates a new database command
                MySqlCommand cmd = new MySqlCommand();
                // Sets the query in the database command
                cmd.CommandText = "SELECT ingredients_id, ingredients_name, ingredients_cost, ingredient_stock FROM ingredients";
                // Sets the connection for the database command
                cmd.Connection = connect;
                // Creates new data adapter to hold data from query
                ingredientAdapter = new MySqlDataAdapter();
                // Sets the MySql command for the adapter
                ingredientAdapter.SelectCommand = cmd;
                // Creates a new datatable
                ingredientTable = new DataTable();
                // Adapter fills the table
                ingredientAdapter.Fill(ingredientTable);
                // Dropdown gets the data from the table
                choose_StockNameOLD.DataSource = ingredientTable;
                // Displays the specified data
                choose_StockNameOLD.DisplayMember = "ingredients_name";
                // Identifies each item by id
                choose_StockNameOLD.ValueMember = "ingredients_id";
                // close connection
                connect.Close();
            }
        }

        // Choose stock name old selected index
        private void choose_StockNameOLD_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Selects the old stock name
            // Connects to the database
            db_connection();
            // if statement, if stock type = 0
            // stock data is from Asset
            if (choose_StockTypeOLD.SelectedIndex == 0)
            {
                // New command query to read the query
                cmd = new MySqlCommand("SELECT * FROM escaperoom_assets where asset_name ='" + choose_StockNameOLD.Text + "'", connect);
                // Executes the command
                cmd.ExecuteNonQuery();
                // Data reader for asset
                MySqlDataReader assetReader;
                // Command activates reader
                assetReader = cmd.ExecuteReader();
                // While statement for reader
                // Reads the input
                // Converts query column into strings
                // Textbox equals string
                while (assetReader.Read())
                {
                    string assetName = (string)assetReader["asset_name"].ToString();
                    txt_StockName_OLD.Text = assetName;

                    string assetStatus = (string)assetReader["asset_status"].ToString();
                    txt_StockStatus_OLD.Text = assetStatus;

                    txt_StockTotal_OLD.Clear();
                    txt_StockCost_OLD.Clear();
                }
            }
            // else if statement, if stock type = 1
            // stock data is from Ingredients
            else if (choose_StockTypeOLD.SelectedIndex == 1)
            {
                // New command query to read the query
                cmd = new MySqlCommand("SELECT * FROM ingredients where ingredients_name ='" + choose_StockNameOLD.Text + "'", connect);
                // Executes the command
                cmd.ExecuteNonQuery();
                // Data reader for ingredient
                MySqlDataReader ingreReader;
                // Command activates reader
                ingreReader = cmd.ExecuteReader();
                // While statement for reader
                // Reads the input
                // Converts query column into strings
                // Textbox equals string
                while (ingreReader.Read())
                {
                    string ingreName = (string)ingreReader["ingredients_name"].ToString();
                    txt_StockName_OLD.Text = ingreName;

                    string ingreStockTotal = (string)ingreReader["ingredient_stock"].ToString();
                    txt_StockTotal_OLD.Text = ingreStockTotal;

                    string ingreCost = (string)ingreReader["ingredients_cost"].ToString();
                    txt_StockCost_OLD.Text = ingreCost;

                    txt_StockStatus_OLD.Clear();

                }
            }
        }

        // asset status selected index
        private void asset_Status_SelectedIndexChanged(object sender, EventArgs e)
        {
            // if statement, if asset status = 0
            // asset status = clean
            // Render as "1" and read only
            if (asset_Status.SelectedIndex == 0)
            {
                txt_AssetAvailability.Text = "1";
                txt_AssetAvailability.ReadOnly = true;
            }
            // else if statement, if asset status = 0
            // asset status = dirty
            // Render as "0" and read only
            else if (asset_Status.SelectedIndex == 1)
            {
                txt_AssetAvailability.Text = "0";
                txt_AssetAvailability.ReadOnly = true;
            }
        }

        // Ingredient stock keypress
        private void txt_IngredientStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Checks if input characters are numbers only.
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                // Only allow numbers.
                e.Handled = true;
            }
        }

        // Ingredient Stock text change
        private void txt_IngredientStock_TextChanged(object sender, EventArgs e)
        {
            // Creates a new integer
            int ingreTotal;
            // creates a new boolean
            // Sets text box as an integer
            bool ingreAvail = Int32.TryParse(txt_IngredientStock.Text, out ingreTotal);
            // if statement, if ingredient total is greater than 0
            // Render text as "1" and read only
            if (ingreTotal > 0)
            {
                txt_IngredientAvail.Text = "1";
                txt_IngredientAvail.ReadOnly = true;
            }
            // else if statement, if ingredient total is greater than 0
            // Render text as "0" and read only
            else if (ingreTotal <= 0)
            {
                txt_IngredientAvail.Text = "0";
                txt_IngredientAvail.ReadOnly = true;
            }
        }
    }
}
