﻿
namespace Adventure_StaffApplicationMenu
{
    partial class Delete_StorageItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.delete_StockItem = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.txt_StockCost_DLT = new System.Windows.Forms.TextBox();
            this.txt_StockTotal_DLT = new System.Windows.Forms.TextBox();
            this.txt_StockStatus_DLT = new System.Windows.Forms.TextBox();
            this.txt_StockName_DLT = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.choose_StockTypeDLT = new System.Windows.Forms.ComboBox();
            this.choose_StockItemDLT = new System.Windows.Forms.ComboBox();
            this.txt_StockID_DLT = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_StockType = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // delete_StockItem
            // 
            this.delete_StockItem.Location = new System.Drawing.Point(422, 233);
            this.delete_StockItem.Name = "delete_StockItem";
            this.delete_StockItem.Size = new System.Drawing.Size(75, 23);
            this.delete_StockItem.TabIndex = 78;
            this.delete_StockItem.Text = "Delete";
            this.delete_StockItem.UseVisualStyleBackColor = true;
            this.delete_StockItem.Click += new System.EventHandler(this.delete_StockItem_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(303, 233);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 77;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // txt_StockCost_DLT
            // 
            this.txt_StockCost_DLT.Location = new System.Drawing.Point(460, 204);
            this.txt_StockCost_DLT.Name = "txt_StockCost_DLT";
            this.txt_StockCost_DLT.Size = new System.Drawing.Size(143, 23);
            this.txt_StockCost_DLT.TabIndex = 66;
            // 
            // txt_StockTotal_DLT
            // 
            this.txt_StockTotal_DLT.Location = new System.Drawing.Point(460, 177);
            this.txt_StockTotal_DLT.Name = "txt_StockTotal_DLT";
            this.txt_StockTotal_DLT.Size = new System.Drawing.Size(143, 23);
            this.txt_StockTotal_DLT.TabIndex = 65;
            // 
            // txt_StockStatus_DLT
            // 
            this.txt_StockStatus_DLT.Location = new System.Drawing.Point(235, 204);
            this.txt_StockStatus_DLT.Name = "txt_StockStatus_DLT";
            this.txt_StockStatus_DLT.Size = new System.Drawing.Size(143, 23);
            this.txt_StockStatus_DLT.TabIndex = 64;
            // 
            // txt_StockName_DLT
            // 
            this.txt_StockName_DLT.Location = new System.Drawing.Point(235, 177);
            this.txt_StockName_DLT.Name = "txt_StockName_DLT";
            this.txt_StockName_DLT.Size = new System.Drawing.Size(143, 23);
            this.txt_StockName_DLT.TabIndex = 63;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(388, 207);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 15);
            this.label6.TabIndex = 62;
            this.label6.Text = "Stock Cost:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(155, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 15);
            this.label5.TabIndex = 61;
            this.label5.Text = "Stock Status:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(388, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 60;
            this.label7.Text = "Total Stock:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(155, 180);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 15);
            this.label8.TabIndex = 59;
            this.label8.Text = "Stock Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(346, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 21);
            this.label2.TabIndex = 57;
            this.label2.Text = "Stock Info";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(312, 64);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(157, 21);
            this.Label4.TabIndex = 55;
            this.Label4.Text = "Delete a storage item";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(235, 23);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 54;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // choose_StockTypeDLT
            // 
            this.choose_StockTypeDLT.FormattingEnabled = true;
            this.choose_StockTypeDLT.Location = new System.Drawing.Point(214, 120);
            this.choose_StockTypeDLT.Name = "choose_StockTypeDLT";
            this.choose_StockTypeDLT.Size = new System.Drawing.Size(121, 23);
            this.choose_StockTypeDLT.TabIndex = 79;
            this.choose_StockTypeDLT.Text = "Type of Stock?";
            this.choose_StockTypeDLT.SelectedIndexChanged += new System.EventHandler(this.choose_StockTypeDLT_SelectedIndexChanged);
            // 
            // choose_StockItemDLT
            // 
            this.choose_StockItemDLT.FormattingEnabled = true;
            this.choose_StockItemDLT.Location = new System.Drawing.Point(440, 120);
            this.choose_StockItemDLT.Name = "choose_StockItemDLT";
            this.choose_StockItemDLT.Size = new System.Drawing.Size(121, 23);
            this.choose_StockItemDLT.TabIndex = 80;
            this.choose_StockItemDLT.Text = "Select a Product";
            this.choose_StockItemDLT.SelectedIndexChanged += new System.EventHandler(this.choose_StockItemDLT_SelectedIndexChanged);
            // 
            // txt_StockID_DLT
            // 
            this.txt_StockID_DLT.Location = new System.Drawing.Point(235, 148);
            this.txt_StockID_DLT.Name = "txt_StockID_DLT";
            this.txt_StockID_DLT.Size = new System.Drawing.Size(143, 23);
            this.txt_StockID_DLT.TabIndex = 81;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(176, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 15);
            this.label3.TabIndex = 82;
            this.label3.Text = "Stock ID:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(389, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 15);
            this.label9.TabIndex = 84;
            this.label9.Text = "Stock Type:";
            // 
            // txt_StockType
            // 
            this.txt_StockType.Location = new System.Drawing.Point(460, 148);
            this.txt_StockType.Name = "txt_StockType";
            this.txt_StockType.Size = new System.Drawing.Size(143, 23);
            this.txt_StockType.TabIndex = 83;
            // 
            // Delete_StorageItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 305);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_StockType);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_StockID_DLT);
            this.Controls.Add(this.choose_StockItemDLT);
            this.Controls.Add(this.choose_StockTypeDLT);
            this.Controls.Add(this.delete_StockItem);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.txt_StockCost_DLT);
            this.Controls.Add(this.txt_StockTotal_DLT);
            this.Controls.Add(this.txt_StockStatus_DLT);
            this.Controls.Add(this.txt_StockName_DLT);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label1);
            this.Name = "Delete_StorageItem";
            this.Text = "Delete_StorageItem";
            this.Load += new System.EventHandler(this.Delete_StorageItem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button delete_StockItem;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.TextBox txt_StockCost_DLT;
        private System.Windows.Forms.TextBox txt_StockTotal_DLT;
        private System.Windows.Forms.TextBox txt_StockStatus_DLT;
        private System.Windows.Forms.TextBox txt_StockName_DLT;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.ComboBox choose_StockTypeDLT;
        private System.Windows.Forms.ComboBox choose_StockItemDLT;
        private System.Windows.Forms.TextBox txt_StockID_DLT;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_StockType;
    }
}