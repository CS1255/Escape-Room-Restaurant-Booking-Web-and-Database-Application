﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Adventure_StaffApplicationMenu
{
    public partial class Staff_Availability_Form : Form
    {
        // These properties help connect to
        // or use data from the database
        private string conn;
        private MySqlConnection connect;
        MySqlCommand cmd;
        private MySqlDataAdapter staffAdapter;
        private DataTable staffTable;
        public Staff_Availability_Form()
        {
            // Initializes form
            InitializeComponent();
        }

        // Database Connection code
        private void db_connection()
        {
            // Connects to the database
            try
            {
                conn = "Server=localhost;Database=escape;Uid=root;Pwd=root;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        // Staff availability form load
        private void Staff_Availability_Form_Load(object sender, EventArgs e)
        {
            // Selects the specific staff member
            // Opens the database connection
            db_connection();
            // Creates a new database command
            MySqlCommand cmd = new MySqlCommand();
            // Sets the query in the database command
            cmd.CommandText = "SELECT staff_id, staff_firstname, staff_surname, staff_email, staff_phone, staff_availability from staff";
            // Sets the connection for the database command
            cmd.Connection = connect;
            // Creates a new adapter to hold the data from the query
            staffAdapter = new MySqlDataAdapter();
            // Set the MySql command for the adapter
            staffAdapter.SelectCommand = cmd;
            // Creates a new datatable
            staffTable = new DataTable();
            // Adapter fills the table
            staffAdapter.Fill(staffTable);
            // Dropdown gets the data from the table
            choose_StaffMember.DataSource = staffTable;
            // Displays the specified data
            choose_StaffMember.DisplayMember = "staff_firstname";
            // Identifies each item by id
            choose_StaffMember.ValueMember = "staff_id";
        }

        // Cancel button
        private void cancel_Click(object sender, EventArgs e)
        {
            // Closes form
            Close();
        }

        // Mark staff button
        private void mark_StaffMember_Click(object sender, EventArgs e)
        {
            // Mark staff availability
            // Connects to the database
            db_connection();
            // String is the textbox input
            string newAvailability = txt_Staff_availability.Text;
            // Update query through string input and trhough selected staff member
            string query = "UPDATE staff SET staff_availability = '" + newAvailability + "' where staff_firstname = '" + choose_StaffMember.Text + "'";
            // New command to activate query
            cmd = new MySqlCommand(query, connect);
            // Prompt message
            MessageBox.Show("Staff has been marked!");
            // Execute Query
            cmd.ExecuteNonQuery();
        }

        // Choose staff member select index
        private void choose_StaffMember_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Select staff member
            // Connects to the database
            db_connection();
            // New command to read the query
            cmd = new MySqlCommand("SELECT * FROM staff where staff_firstname ='" + choose_StaffMember.Text + "'", connect);
            // Executes the command
            cmd.ExecuteNonQuery();
            // Data reader for staff availability
            MySqlDataReader staffReader;
            // Command activates reader
            staffReader = cmd.ExecuteReader();
            // While statement for reader
            // Reads the input
            // Converts query column into strings
            // Textbox equals string
            while (staffReader.Read())
            {
                string staffID = (string)staffReader["staff_id"].ToString();
                txt_Staff_ID.Text = staffID;

                string staffFirstName = (string)staffReader["staff_firstname"].ToString();
                txt_Staff_firstName.Text = staffFirstName;

                string staffSurName = (string)staffReader["staff_surname"].ToString();
                txt_Staff_surName.Text = staffSurName;

                string staffEmail = (string)staffReader["staff_email"].ToString();
                txt_Staff_email.Text = staffEmail;

                string staffPhone = (string)staffReader["staff_phone"].ToString();
                txt_Staff_phone.Text = staffPhone;
            }
        }

        // Choose availability boolean
        private void choose_AvailBoolean_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Select availability option
            // Connects to the database
            db_connection();
            // if statement, if availability option = 0
            // Text option = "Yes"
            // Render as "1" and read only
            if (choose_AvailBoolean.SelectedIndex == 0)
            {
                txt_Staff_availability.Text = "1";
                txt_Staff_availability.ReadOnly = true;
            }
            // else if statement, if availability option = 1
            // Text option = "No"
            // Render as "0" and read only
            else if (choose_AvailBoolean.SelectedIndex == 1)
            {
                txt_Staff_availability.Text = "0";
                txt_Staff_availability.ReadOnly = true;
            }
        }
    }
}
