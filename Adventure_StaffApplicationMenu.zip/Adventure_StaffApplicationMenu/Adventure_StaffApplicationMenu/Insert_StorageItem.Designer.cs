﻿
namespace Adventure_StaffApplicationMenu
{
    partial class Insert_StorageItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.cancel = new System.Windows.Forms.Button();
            this.stock_Type = new System.Windows.Forms.ComboBox();
            this.add_StockItem = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_IngredientStock = new System.Windows.Forms.TextBox();
            this.asset_Status = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_IngredientCost = new System.Windows.Forms.TextBox();
            this.txt_IngredientName = new System.Windows.Forms.TextBox();
            this.txt_AssetAvailability = new System.Windows.Forms.TextBox();
            this.txt_AssetName = new System.Windows.Forms.TextBox();
            this.txt_AssetID = new System.Windows.Forms.TextBox();
            this.txt_IngredientID = new System.Windows.Forms.TextBox();
            this.txt_IngredientAvail = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(324, 88);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(174, 21);
            this.Label4.TabIndex = 19;
            this.Label4.Text = "Add a new storage item";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(227, 45);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 18;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(305, 348);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 34;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // stock_Type
            // 
            this.stock_Type.FormattingEnabled = true;
            this.stock_Type.Location = new System.Drawing.Point(352, 122);
            this.stock_Type.Name = "stock_Type";
            this.stock_Type.Size = new System.Drawing.Size(121, 23);
            this.stock_Type.TabIndex = 36;
            this.stock_Type.Text = "Type of Stock?";
            this.stock_Type.SelectedIndexChanged += new System.EventHandler(this.stock_Type_SelectedIndexChanged);
            // 
            // add_StockItem
            // 
            this.add_StockItem.Location = new System.Drawing.Point(423, 348);
            this.add_StockItem.Name = "add_StockItem";
            this.add_StockItem.Size = new System.Drawing.Size(75, 23);
            this.add_StockItem.TabIndex = 37;
            this.add_StockItem.Text = "Add";
            this.add_StockItem.UseVisualStyleBackColor = true;
            this.add_StockItem.Click += new System.EventHandler(this.add_StockItem_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(229, 162);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 19);
            this.label2.TabIndex = 38;
            this.label2.Text = "Asset";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(528, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 19);
            this.label3.TabIndex = 39;
            this.label3.Text = "Ingredient";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(150, 224);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 15);
            this.label5.TabIndex = 40;
            this.label5.Text = "Asset Name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(150, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 15);
            this.label6.TabIndex = 41;
            this.label6.Text = "Asset Status:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(124, 282);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 15);
            this.label7.TabIndex = 42;
            this.label7.Text = "Asset Availability:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(422, 224);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 15);
            this.label8.TabIndex = 46;
            this.label8.Text = "Ingredient Name:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(430, 253);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 15);
            this.label9.TabIndex = 47;
            this.label9.Text = "Ingredient Cost:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(425, 282);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 15);
            this.label10.TabIndex = 48;
            this.label10.Text = "Ingredient Stock:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(396, 311);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 15);
            this.label11.TabIndex = 49;
            this.label11.Text = "Ingredient Availability:";
            // 
            // txt_IngredientStock
            // 
            this.txt_IngredientStock.Location = new System.Drawing.Point(528, 280);
            this.txt_IngredientStock.Name = "txt_IngredientStock";
            this.txt_IngredientStock.Size = new System.Drawing.Size(121, 23);
            this.txt_IngredientStock.TabIndex = 52;
            this.txt_IngredientStock.TextChanged += new System.EventHandler(this.txt_IngredientStock_TextChanged);
            this.txt_IngredientStock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_IngredientStock_KeyPress);
            // 
            // asset_Status
            // 
            this.asset_Status.FormattingEnabled = true;
            this.asset_Status.Location = new System.Drawing.Point(229, 250);
            this.asset_Status.Name = "asset_Status";
            this.asset_Status.Size = new System.Drawing.Size(121, 23);
            this.asset_Status.TabIndex = 54;
            this.asset_Status.Text = "Status";
            this.asset_Status.SelectedIndexChanged += new System.EventHandler(this.asset_Status_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(443, 196);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 15);
            this.label12.TabIndex = 55;
            this.label12.Text = "Ingredient ID:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(171, 196);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 15);
            this.label13.TabIndex = 57;
            this.label13.Text = "Asset ID:";
            // 
            // txt_IngredientCost
            // 
            this.txt_IngredientCost.Location = new System.Drawing.Point(528, 250);
            this.txt_IngredientCost.Name = "txt_IngredientCost";
            this.txt_IngredientCost.Size = new System.Drawing.Size(121, 23);
            this.txt_IngredientCost.TabIndex = 62;
            // 
            // txt_IngredientName
            // 
            this.txt_IngredientName.Location = new System.Drawing.Point(528, 221);
            this.txt_IngredientName.Name = "txt_IngredientName";
            this.txt_IngredientName.Size = new System.Drawing.Size(121, 23);
            this.txt_IngredientName.TabIndex = 61;
            // 
            // txt_AssetAvailability
            // 
            this.txt_AssetAvailability.Location = new System.Drawing.Point(229, 279);
            this.txt_AssetAvailability.Name = "txt_AssetAvailability";
            this.txt_AssetAvailability.Size = new System.Drawing.Size(121, 23);
            this.txt_AssetAvailability.TabIndex = 60;
            // 
            // txt_AssetName
            // 
            this.txt_AssetName.Location = new System.Drawing.Point(229, 221);
            this.txt_AssetName.Name = "txt_AssetName";
            this.txt_AssetName.Size = new System.Drawing.Size(121, 23);
            this.txt_AssetName.TabIndex = 59;
            // 
            // txt_AssetID
            // 
            this.txt_AssetID.Location = new System.Drawing.Point(229, 192);
            this.txt_AssetID.Name = "txt_AssetID";
            this.txt_AssetID.Size = new System.Drawing.Size(121, 23);
            this.txt_AssetID.TabIndex = 65;
            // 
            // txt_IngredientID
            // 
            this.txt_IngredientID.Location = new System.Drawing.Point(528, 192);
            this.txt_IngredientID.Name = "txt_IngredientID";
            this.txt_IngredientID.Size = new System.Drawing.Size(121, 23);
            this.txt_IngredientID.TabIndex = 64;
            // 
            // txt_IngredientAvail
            // 
            this.txt_IngredientAvail.Location = new System.Drawing.Point(528, 308);
            this.txt_IngredientAvail.Name = "txt_IngredientAvail";
            this.txt_IngredientAvail.Size = new System.Drawing.Size(121, 23);
            this.txt_IngredientAvail.TabIndex = 63;
            // 
            // Insert_StorageItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 420);
            this.Controls.Add(this.txt_AssetID);
            this.Controls.Add(this.txt_IngredientID);
            this.Controls.Add(this.txt_IngredientAvail);
            this.Controls.Add(this.txt_IngredientCost);
            this.Controls.Add(this.txt_IngredientName);
            this.Controls.Add(this.txt_AssetAvailability);
            this.Controls.Add(this.txt_AssetName);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.asset_Status);
            this.Controls.Add(this.txt_IngredientStock);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.add_StockItem);
            this.Controls.Add(this.stock_Type);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label1);
            this.Name = "Insert_StorageItem";
            this.Text = "Insert_StorageItem";
            this.Load += new System.EventHandler(this.Insert_StorageItem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.ComboBox stock_Type;
        private System.Windows.Forms.Button add_StockItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_IngredientStock;
        private System.Windows.Forms.ComboBox asset_Status;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_IngredientCost;
        private System.Windows.Forms.TextBox txt_IngredientName;
        private System.Windows.Forms.TextBox txt_AssetAvailability;
        private System.Windows.Forms.TextBox txt_AssetName;
        private System.Windows.Forms.TextBox txt_AssetID;
        private System.Windows.Forms.TextBox txt_IngredientID;
        private System.Windows.Forms.TextBox txt_IngredientAvail;
    }
}