﻿
namespace Adventure_StaffApplicationMenu
{
    partial class Staff_Availability_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mark_StaffMember = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.choose_StaffMember = new System.Windows.Forms.ComboBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.choose_AvailBoolean = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_Staff_ID = new System.Windows.Forms.TextBox();
            this.txt_Staff_availability = new System.Windows.Forms.TextBox();
            this.txt_Staff_firstName = new System.Windows.Forms.TextBox();
            this.txt_Staff_surName = new System.Windows.Forms.TextBox();
            this.txt_Staff_phone = new System.Windows.Forms.TextBox();
            this.txt_Staff_email = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // mark_StaffMember
            // 
            this.mark_StaffMember.Location = new System.Drawing.Point(431, 239);
            this.mark_StaffMember.Name = "mark_StaffMember";
            this.mark_StaffMember.Size = new System.Drawing.Size(75, 23);
            this.mark_StaffMember.TabIndex = 78;
            this.mark_StaffMember.Text = "Mark";
            this.mark_StaffMember.UseVisualStyleBackColor = true;
            this.mark_StaffMember.Click += new System.EventHandler(this.mark_StaffMember_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(305, 239);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 77;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // choose_StaffMember
            // 
            this.choose_StaffMember.FormattingEnabled = true;
            this.choose_StaffMember.Location = new System.Drawing.Point(235, 102);
            this.choose_StaffMember.Name = "choose_StaffMember";
            this.choose_StaffMember.Size = new System.Drawing.Size(151, 23);
            this.choose_StaffMember.TabIndex = 67;
            this.choose_StaffMember.Text = "Choose a Staff Member";
            this.choose_StaffMember.SelectedIndexChanged += new System.EventHandler(this.choose_StaffMember_SelectedIndexChanged);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(312, 64);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(161, 21);
            this.Label4.TabIndex = 55;
            this.Label4.Text = "Mark Staff Availability";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(235, 23);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 54;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // choose_AvailBoolean
            // 
            this.choose_AvailBoolean.FormattingEnabled = true;
            this.choose_AvailBoolean.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.choose_AvailBoolean.Location = new System.Drawing.Point(421, 102);
            this.choose_AvailBoolean.Name = "choose_AvailBoolean";
            this.choose_AvailBoolean.Size = new System.Drawing.Size(151, 23);
            this.choose_AvailBoolean.TabIndex = 79;
            this.choose_AvailBoolean.Text = "Are they available?";
            this.choose_AvailBoolean.SelectedIndexChanged += new System.EventHandler(this.choose_AvailBoolean_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(140, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 15);
            this.label2.TabIndex = 80;
            this.label2.Text = "Staff Firstname:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(382, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 15);
            this.label3.TabIndex = 81;
            this.label3.Text = "Staff Surname:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(163, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 15);
            this.label5.TabIndex = 82;
            this.label5.Text = "Staff Email:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(395, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 15);
            this.label6.TabIndex = 83;
            this.label6.Text = "Staff Phone:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(181, 134);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 15);
            this.label7.TabIndex = 84;
            this.label7.Text = "Staff ID:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(371, 134);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 15);
            this.label8.TabIndex = 85;
            this.label8.Text = "Staff Availability:";
            // 
            // txt_Staff_ID
            // 
            this.txt_Staff_ID.Location = new System.Drawing.Point(235, 131);
            this.txt_Staff_ID.Name = "txt_Staff_ID";
            this.txt_Staff_ID.Size = new System.Drawing.Size(100, 23);
            this.txt_Staff_ID.TabIndex = 86;
            // 
            // txt_Staff_availability
            // 
            this.txt_Staff_availability.Location = new System.Drawing.Point(472, 131);
            this.txt_Staff_availability.Name = "txt_Staff_availability";
            this.txt_Staff_availability.Size = new System.Drawing.Size(100, 23);
            this.txt_Staff_availability.TabIndex = 87;
            // 
            // txt_Staff_firstName
            // 
            this.txt_Staff_firstName.Location = new System.Drawing.Point(235, 160);
            this.txt_Staff_firstName.Name = "txt_Staff_firstName";
            this.txt_Staff_firstName.Size = new System.Drawing.Size(100, 23);
            this.txt_Staff_firstName.TabIndex = 88;
            // 
            // txt_Staff_surName
            // 
            this.txt_Staff_surName.Location = new System.Drawing.Point(472, 160);
            this.txt_Staff_surName.Name = "txt_Staff_surName";
            this.txt_Staff_surName.Size = new System.Drawing.Size(100, 23);
            this.txt_Staff_surName.TabIndex = 89;
            // 
            // txt_Staff_phone
            // 
            this.txt_Staff_phone.Location = new System.Drawing.Point(472, 189);
            this.txt_Staff_phone.Name = "txt_Staff_phone";
            this.txt_Staff_phone.Size = new System.Drawing.Size(100, 23);
            this.txt_Staff_phone.TabIndex = 90;
            // 
            // txt_Staff_email
            // 
            this.txt_Staff_email.Location = new System.Drawing.Point(235, 189);
            this.txt_Staff_email.Name = "txt_Staff_email";
            this.txt_Staff_email.Size = new System.Drawing.Size(151, 23);
            this.txt_Staff_email.TabIndex = 91;
            // 
            // Staff_Availability_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 295);
            this.Controls.Add(this.txt_Staff_email);
            this.Controls.Add(this.txt_Staff_phone);
            this.Controls.Add(this.txt_Staff_surName);
            this.Controls.Add(this.txt_Staff_firstName);
            this.Controls.Add(this.txt_Staff_availability);
            this.Controls.Add(this.txt_Staff_ID);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.choose_AvailBoolean);
            this.Controls.Add(this.mark_StaffMember);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.choose_StaffMember);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label1);
            this.Name = "Staff_Availability_Form";
            this.Text = "Staff_Availability_Form";
            this.Load += new System.EventHandler(this.Staff_Availability_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button mark_StaffMember;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.ComboBox choose_StaffMember;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.ComboBox choose_AvailBoolean;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_Staff_ID;
        private System.Windows.Forms.TextBox txt_Staff_availability;
        private System.Windows.Forms.TextBox txt_Staff_firstName;
        private System.Windows.Forms.TextBox txt_Staff_surName;
        private System.Windows.Forms.TextBox txt_Staff_phone;
        private System.Windows.Forms.TextBox txt_Staff_email;
    }
}