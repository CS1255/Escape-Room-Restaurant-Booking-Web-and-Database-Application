﻿namespace Adventure_StaffApplicationMenu
{
    partial class Staff_Menu_Form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Exit_Button = new System.Windows.Forms.Button();
            this.StaffList_Button = new System.Windows.Forms.Button();
            this.StorList_Button = new System.Windows.Forms.Button();
            this.CustList_Button = new System.Windows.Forms.Button();
            this.CustOrders_Button = new System.Windows.Forms.Button();
            this.CustBookings_Button = new System.Windows.Forms.Button();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Exit_Button
            // 
            this.Exit_Button.Location = new System.Drawing.Point(12, 12);
            this.Exit_Button.Name = "Exit_Button";
            this.Exit_Button.Size = new System.Drawing.Size(108, 33);
            this.Exit_Button.TabIndex = 18;
            this.Exit_Button.Text = "Exit Application";
            this.Exit_Button.UseVisualStyleBackColor = true;
            this.Exit_Button.Click += new System.EventHandler(this.Exit_Button_Click);
            // 
            // StaffList_Button
            // 
            this.StaffList_Button.Location = new System.Drawing.Point(419, 183);
            this.StaffList_Button.Name = "StaffList_Button";
            this.StaffList_Button.Size = new System.Drawing.Size(108, 54);
            this.StaffList_Button.TabIndex = 17;
            this.StaffList_Button.Text = "List of Staff";
            this.StaffList_Button.UseVisualStyleBackColor = true;
            this.StaffList_Button.Click += new System.EventHandler(this.StaffList_Button_Click);
            // 
            // StorList_Button
            // 
            this.StorList_Button.Location = new System.Drawing.Point(281, 183);
            this.StorList_Button.Name = "StorList_Button";
            this.StorList_Button.Size = new System.Drawing.Size(108, 54);
            this.StorList_Button.TabIndex = 16;
            this.StorList_Button.Text = "Storage";
            this.StorList_Button.UseVisualStyleBackColor = true;
            this.StorList_Button.Click += new System.EventHandler(this.StorList_Button_Click);
            // 
            // CustList_Button
            // 
            this.CustList_Button.Location = new System.Drawing.Point(483, 109);
            this.CustList_Button.Name = "CustList_Button";
            this.CustList_Button.Size = new System.Drawing.Size(108, 54);
            this.CustList_Button.TabIndex = 15;
            this.CustList_Button.Text = "List of Customers";
            this.CustList_Button.UseVisualStyleBackColor = true;
            this.CustList_Button.Click += new System.EventHandler(this.CustList_Button_Click);
            // 
            // CustOrders_Button
            // 
            this.CustOrders_Button.Location = new System.Drawing.Point(349, 109);
            this.CustOrders_Button.Name = "CustOrders_Button";
            this.CustOrders_Button.Size = new System.Drawing.Size(108, 54);
            this.CustOrders_Button.TabIndex = 14;
            this.CustOrders_Button.Text = "View Customer Orders";
            this.CustOrders_Button.UseVisualStyleBackColor = true;
            this.CustOrders_Button.Click += new System.EventHandler(this.CustOrders_Button_Click);
            // 
            // CustBookings_Button
            // 
            this.CustBookings_Button.Location = new System.Drawing.Point(212, 109);
            this.CustBookings_Button.Name = "CustBookings_Button";
            this.CustBookings_Button.Size = new System.Drawing.Size(108, 54);
            this.CustBookings_Button.TabIndex = 13;
            this.CustBookings_Button.Text = "View Customer Bookings";
            this.CustBookings_Button.UseVisualStyleBackColor = true;
            this.CustBookings_Button.Click += new System.EventHandler(this.CustBookings_Button_Click);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(320, 69);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(177, 21);
            this.Label4.TabIndex = 12;
            this.Label4.Text = "Please choose an option";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(242, 27);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 19;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // Staff_Menu_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Exit_Button);
            this.Controls.Add(this.StaffList_Button);
            this.Controls.Add(this.StorList_Button);
            this.Controls.Add(this.CustList_Button);
            this.Controls.Add(this.CustOrders_Button);
            this.Controls.Add(this.CustBookings_Button);
            this.Controls.Add(this.Label4);
            this.Name = "Staff_Menu_Form";
            this.Text = "Staff Menu";
            this.Load += new System.EventHandler(this.Staff_Menu_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button Exit_Button;
        internal System.Windows.Forms.Button StaffList_Button;
        internal System.Windows.Forms.Button StorList_Button;
        internal System.Windows.Forms.Button CustList_Button;
        internal System.Windows.Forms.Button CustOrders_Button;
        internal System.Windows.Forms.Button CustBookings_Button;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
    }
}

