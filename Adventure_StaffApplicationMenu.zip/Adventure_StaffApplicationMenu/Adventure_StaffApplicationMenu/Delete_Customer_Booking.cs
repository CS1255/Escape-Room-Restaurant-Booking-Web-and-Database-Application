﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Adventure_StaffApplicationMenu
{
    public partial class Delete_Customer_Booking : Form
    {
        // These properties help connect to
        // or use data from the database
        private string conn;
        private MySqlConnection connect;
        MySqlCommand cmd;
        private MySqlDataAdapter bookingAdapter;
        private DataTable bookingTable;
        public Delete_Customer_Booking()
        {
            // Initializes form
            InitializeComponent();
        }

        // Database Connection code
        private void db_connection()
        {
            // Connects to the database
            try
            {
                conn = "Server=localhost;Database=escape;Uid=root;Pwd=root;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        // Remove booking button
        private void remove_Booking_Click(object sender, EventArgs e)
        {
            // Removes the booking
            // Connects to the database
            db_connection();
            // Query deletes booking from text input
            string query = "DELETE from bookings_list where custBooking_id = '" + txt_Custbooking_ID.Text + "'";
            // New command to activate the query
            cmd = new MySqlCommand(query, connect);
            // Prompt message
            MessageBox.Show("Delete Successful!");
            // Executes the command
            cmd.ExecuteNonQuery();
        }

        // Delete Customer Booking Load
        private void Delete_Customer_Booking_Load(object sender, EventArgs e)
        {
            // Selects the specific booking
            // Connects to the database
            db_connection();
            // Creatse a new database command
            MySqlCommand cmd = new MySqlCommand();
            // Sets the query in the database command
            cmd.CommandText = "SELECT custBooking_id, custBooking_firstName, custBooking_surName, custBooking_escName, custBooking_totAdult, custBooking_totChild, custBooking_totPrice from bookings_list";
            // Sets the connection for the database command
            cmd.Connection = connect;
            // Creates a new adapter to hold the data from the query
            bookingAdapter = new MySqlDataAdapter();
            // Set the MySql command for the adapter
            bookingAdapter.SelectCommand = cmd;
            // Creates a new datatable
            bookingTable = new DataTable();
            // Adapter fills the table
            bookingAdapter.Fill(bookingTable);
            // Dropdown gets the data from the table
            choose_Booking.DataSource = bookingTable;
            // Displays the specified data
            choose_Booking.DisplayMember = "custBooking_firstName";
            // Identifies each item by id
            choose_Booking.ValueMember = "custBooking_id";
            // close connection
            connect.Close();
        }

        // Choose booking selected index
        private void choose_Booking_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Changes data output
            // Connectes to the database
            db_connection();
            // New command to read the query
            cmd = new MySqlCommand("SELECT * FROM bookings_list where custBooking_firstName ='" + choose_Booking.Text + "'", connect);
            // Executes the command
            cmd.ExecuteNonQuery();
            // Data reader for booking
            MySqlDataReader bookingReader;
            // Command activates reader
            bookingReader = cmd.ExecuteReader();
            // While statement for reader
            // Reads the input
            // Converts query column into strings
            // Textbox equals string
            while (bookingReader.Read())
            {
                string bookingID = (string)bookingReader["custBooking_id"].ToString();
                txt_Custbooking_ID.Text = bookingID;

                string custFirstName = (string)bookingReader["custBooking_firstName"].ToString();
                txt_Custbooking_firstName.Text = custFirstName;

                string custSurName = (string)bookingReader["custBooking_surName"].ToString();
                txt_Custbooking_surName.Text = custSurName;

                string escBookName = (string)bookingReader["custBooking_escName"].ToString();
                txt_Custbooking_escName.Text = escBookName;

                string totAdults = (string)bookingReader["custBooking_totAdult"].ToString();
                txt_Custbooking_totAdults.Text = totAdults;

                string totChildren = (string)bookingReader["custBooking_totChild"].ToString();
                txt_Custbooking_totChild.Text = totChildren;

                string totPrice = (string)bookingReader["custBooking_totPrice"].ToString();
                txt_Custbooking_totPrice.Text = totPrice;
            }
        }

        // Cancel button
        private void cancel_Click(object sender, EventArgs e)
        {
            // Closes form
            Close();
        }
    }
}
