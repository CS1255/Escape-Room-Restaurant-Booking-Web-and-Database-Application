﻿
namespace Adventure_StaffApplicationMenu
{
    partial class Update_StorageItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_StockCost_OLD = new System.Windows.Forms.TextBox();
            this.txt_StockTotal_OLD = new System.Windows.Forms.TextBox();
            this.txt_StockStatus_OLD = new System.Windows.Forms.TextBox();
            this.txt_StockName_OLD = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.stock_Type = new System.Windows.Forms.ComboBox();
            this.update_StockItem = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.choose_StockTypeOLD = new System.Windows.Forms.ComboBox();
            this.choose_StockNameOLD = new System.Windows.Forms.ComboBox();
            this.asset_Status = new System.Windows.Forms.ComboBox();
            this.txt_IngredientAvail = new System.Windows.Forms.TextBox();
            this.txt_IngredientStock = new System.Windows.Forms.TextBox();
            this.txt_IngredientCost = new System.Windows.Forms.TextBox();
            this.txt_IngredientName = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_AssetAvailability = new System.Windows.Forms.TextBox();
            this.txt_AssetName = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(311, 74);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(163, 21);
            this.Label4.TabIndex = 21;
            this.Label4.Text = "Update a storage item";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(234, 33);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 20;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(356, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 21);
            this.label2.TabIndex = 23;
            this.label2.Text = "Old Info";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(356, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 21);
            this.label3.TabIndex = 24;
            this.label3.Text = "New Info";
            // 
            // txt_StockCost_OLD
            // 
            this.txt_StockCost_OLD.Location = new System.Drawing.Point(471, 197);
            this.txt_StockCost_OLD.Name = "txt_StockCost_OLD";
            this.txt_StockCost_OLD.Size = new System.Drawing.Size(143, 23);
            this.txt_StockCost_OLD.TabIndex = 41;
            // 
            // txt_StockTotal_OLD
            // 
            this.txt_StockTotal_OLD.Location = new System.Drawing.Point(471, 170);
            this.txt_StockTotal_OLD.Name = "txt_StockTotal_OLD";
            this.txt_StockTotal_OLD.Size = new System.Drawing.Size(143, 23);
            this.txt_StockTotal_OLD.TabIndex = 40;
            // 
            // txt_StockStatus_OLD
            // 
            this.txt_StockStatus_OLD.Location = new System.Drawing.Point(250, 197);
            this.txt_StockStatus_OLD.Name = "txt_StockStatus_OLD";
            this.txt_StockStatus_OLD.Size = new System.Drawing.Size(143, 23);
            this.txt_StockStatus_OLD.TabIndex = 39;
            // 
            // txt_StockName_OLD
            // 
            this.txt_StockName_OLD.Location = new System.Drawing.Point(250, 170);
            this.txt_StockName_OLD.Name = "txt_StockName_OLD";
            this.txt_StockName_OLD.Size = new System.Drawing.Size(143, 23);
            this.txt_StockName_OLD.TabIndex = 38;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(398, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 15);
            this.label6.TabIndex = 37;
            this.label6.Text = "Stock Cost:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(170, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 15);
            this.label5.TabIndex = 36;
            this.label5.Text = "Stock Status:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(398, 173);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 35;
            this.label7.Text = "Total Stock:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(170, 173);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 15);
            this.label8.TabIndex = 34;
            this.label8.Text = "Stock Name:";
            // 
            // stock_Type
            // 
            this.stock_Type.FormattingEnabled = true;
            this.stock_Type.Location = new System.Drawing.Point(343, 265);
            this.stock_Type.Name = "stock_Type";
            this.stock_Type.Size = new System.Drawing.Size(121, 23);
            this.stock_Type.TabIndex = 51;
            this.stock_Type.Text = "Type of Stock?";
            this.stock_Type.SelectedIndexChanged += new System.EventHandler(this.stock_Type_SelectedIndexChanged);
            // 
            // update_StockItem
            // 
            this.update_StockItem.Location = new System.Drawing.Point(437, 463);
            this.update_StockItem.Name = "update_StockItem";
            this.update_StockItem.Size = new System.Drawing.Size(75, 23);
            this.update_StockItem.TabIndex = 53;
            this.update_StockItem.Text = "Update";
            this.update_StockItem.UseVisualStyleBackColor = true;
            this.update_StockItem.Click += new System.EventHandler(this.update_StockItem_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(270, 463);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 52;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // choose_StockTypeOLD
            // 
            this.choose_StockTypeOLD.FormattingEnabled = true;
            this.choose_StockTypeOLD.Location = new System.Drawing.Point(224, 141);
            this.choose_StockTypeOLD.Name = "choose_StockTypeOLD";
            this.choose_StockTypeOLD.Size = new System.Drawing.Size(121, 23);
            this.choose_StockTypeOLD.TabIndex = 54;
            this.choose_StockTypeOLD.Text = "Type of Stock?";
            this.choose_StockTypeOLD.SelectedIndexChanged += new System.EventHandler(this.choose_StockTypeOLD_SelectedIndexChanged);
            // 
            // choose_StockNameOLD
            // 
            this.choose_StockNameOLD.FormattingEnabled = true;
            this.choose_StockNameOLD.Location = new System.Drawing.Point(437, 141);
            this.choose_StockNameOLD.Name = "choose_StockNameOLD";
            this.choose_StockNameOLD.Size = new System.Drawing.Size(121, 23);
            this.choose_StockNameOLD.TabIndex = 55;
            this.choose_StockNameOLD.Text = "Select a Product";
            this.choose_StockNameOLD.SelectedIndexChanged += new System.EventHandler(this.choose_StockNameOLD_SelectedIndexChanged);
            // 
            // asset_Status
            // 
            this.asset_Status.FormattingEnabled = true;
            this.asset_Status.Location = new System.Drawing.Point(224, 355);
            this.asset_Status.Name = "asset_Status";
            this.asset_Status.Size = new System.Drawing.Size(121, 23);
            this.asset_Status.TabIndex = 74;
            this.asset_Status.Text = "Status";
            this.asset_Status.SelectedIndexChanged += new System.EventHandler(this.asset_Status_SelectedIndexChanged);
            // 
            // txt_IngredientAvail
            // 
            this.txt_IngredientAvail.Location = new System.Drawing.Point(523, 414);
            this.txt_IngredientAvail.Name = "txt_IngredientAvail";
            this.txt_IngredientAvail.Size = new System.Drawing.Size(121, 23);
            this.txt_IngredientAvail.TabIndex = 73;
            // 
            // txt_IngredientStock
            // 
            this.txt_IngredientStock.Location = new System.Drawing.Point(523, 385);
            this.txt_IngredientStock.Name = "txt_IngredientStock";
            this.txt_IngredientStock.Size = new System.Drawing.Size(121, 23);
            this.txt_IngredientStock.TabIndex = 72;
            this.txt_IngredientStock.TextChanged += new System.EventHandler(this.txt_IngredientStock_TextChanged);
            // 
            // txt_IngredientCost
            // 
            this.txt_IngredientCost.Location = new System.Drawing.Point(523, 356);
            this.txt_IngredientCost.Name = "txt_IngredientCost";
            this.txt_IngredientCost.Size = new System.Drawing.Size(121, 23);
            this.txt_IngredientCost.TabIndex = 71;
            // 
            // txt_IngredientName
            // 
            this.txt_IngredientName.Location = new System.Drawing.Point(523, 327);
            this.txt_IngredientName.Name = "txt_IngredientName";
            this.txt_IngredientName.Size = new System.Drawing.Size(121, 23);
            this.txt_IngredientName.TabIndex = 70;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(391, 416);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 15);
            this.label11.TabIndex = 69;
            this.label11.Text = "Ingredient Availability:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(420, 387);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 15);
            this.label10.TabIndex = 68;
            this.label10.Text = "Ingredient Stock:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(425, 358);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 15);
            this.label9.TabIndex = 67;
            this.label9.Text = "Ingredient Cost:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(417, 329);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 15);
            this.label14.TabIndex = 66;
            this.label14.Text = "Ingredient Name:";
            // 
            // txt_AssetAvailability
            // 
            this.txt_AssetAvailability.Location = new System.Drawing.Point(224, 385);
            this.txt_AssetAvailability.Name = "txt_AssetAvailability";
            this.txt_AssetAvailability.Size = new System.Drawing.Size(121, 23);
            this.txt_AssetAvailability.TabIndex = 65;
            // 
            // txt_AssetName
            // 
            this.txt_AssetName.Location = new System.Drawing.Point(224, 327);
            this.txt_AssetName.Name = "txt_AssetName";
            this.txt_AssetName.Size = new System.Drawing.Size(121, 23);
            this.txt_AssetName.TabIndex = 64;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(119, 387);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 15);
            this.label15.TabIndex = 63;
            this.label15.Text = "Asset Availability:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(145, 358);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(73, 15);
            this.label16.TabIndex = 62;
            this.label16.Text = "Asset Status:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(145, 329);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 15);
            this.label17.TabIndex = 61;
            this.label17.Text = "Asset Name:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(523, 296);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 19);
            this.label18.TabIndex = 60;
            this.label18.Text = "Ingredient";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(224, 296);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 19);
            this.label19.TabIndex = 59;
            this.label19.Text = "Asset";
            // 
            // Update_StorageItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 516);
            this.Controls.Add(this.asset_Status);
            this.Controls.Add(this.txt_IngredientAvail);
            this.Controls.Add(this.txt_IngredientStock);
            this.Controls.Add(this.txt_IngredientCost);
            this.Controls.Add(this.txt_IngredientName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txt_AssetAvailability);
            this.Controls.Add(this.txt_AssetName);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.choose_StockNameOLD);
            this.Controls.Add(this.choose_StockTypeOLD);
            this.Controls.Add(this.update_StockItem);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.stock_Type);
            this.Controls.Add(this.txt_StockCost_OLD);
            this.Controls.Add(this.txt_StockTotal_OLD);
            this.Controls.Add(this.txt_StockStatus_OLD);
            this.Controls.Add(this.txt_StockName_OLD);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label1);
            this.Name = "Update_StorageItem";
            this.Text = "Choose a Stock Item";
            this.Load += new System.EventHandler(this.Update_StorageItem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_StockCost_OLD;
        private System.Windows.Forms.TextBox txt_StockTotal_OLD;
        private System.Windows.Forms.TextBox txt_StockStatus_OLD;
        private System.Windows.Forms.TextBox txt_StockName_OLD;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox stock_Type;
        private System.Windows.Forms.Button update_StockItem;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.ComboBox choose_StockTypeOLD;
        private System.Windows.Forms.ComboBox choose_StockNameOLD;
        private System.Windows.Forms.ComboBox asset_Status;
        private System.Windows.Forms.TextBox txt_IngredientAvail;
        private System.Windows.Forms.TextBox txt_IngredientStock;
        private System.Windows.Forms.TextBox txt_IngredientCost;
        private System.Windows.Forms.TextBox txt_IngredientName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_AssetAvailability;
        private System.Windows.Forms.TextBox txt_AssetName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
    }
}