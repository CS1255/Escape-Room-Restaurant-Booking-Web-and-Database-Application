﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Adventure_StaffApplicationMenu
{
    public partial class Customer_Bookings_Form : Form
    {
        // These properties help connect to
        // or use data from the database
        private string conn;
        private MySqlConnection connect;
        private MySqlDataAdapter myAdapter;

 
        public Customer_Bookings_Form()
        {
            // Initializes form
            InitializeComponent();
        }

        // Database Connection code
        private void db_connection()
        {
            // Connects to the database
            try
            {
                conn = "Server=localhost;Database=escape;Uid=root;Pwd=root;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        // Return Button
        private void Return_Button_Click(object sender, EventArgs e)
        {
            // Closes the bookings form
            Close();
        }

        // Customer Bookings Form Load
        private void Customer_Bookings_Form_Load(object sender, EventArgs e)
        {

            // Loads the database table
            // Opens the database connection
            db_connection();
            // Creates a database command
            MySqlCommand cmd = new MySqlCommand();
            // Sets the query in the database command,
            // the query is a stored procedure
            cmd.CommandText = "CALL `Bookings List`()";
            // Sets the connection for the database command
            cmd.Connection = connect;
            // Creates a new adapter to hold the query output
            myAdapter = new MySqlDataAdapter();
            // Sets the MySQL command for the adapter
            myAdapter.SelectCommand = cmd;
            // Creates a dataset
            DataSet ds = new DataSet();
            // Adapter fills the dataset.
            myAdapter.Fill(ds);
            // Places the data in the specified table.
            dataCustomerBooking.DataSource = ds.Tables[0];
        }

        // Reload Table button
        private void table_Reload_Click(object sender, EventArgs e)
        {
            // Refreshes the table
            // Open the database connection
            db_connection();
            // Creates a new database command
            MySqlCommand cmd = new MySqlCommand();
            // Sets the query in the database command,
            // the query is a stored procedure
            cmd.CommandText = "CALL `Bookings List`()";
            // Sets the connection for the database command
            cmd.Connection = connect;
            // Creates a new adapter to hold the output from the query
            myAdapter = new MySqlDataAdapter();
            // Sets the MySql command for the adapter
            myAdapter.SelectCommand = cmd;
            // Creates a new dataset
            DataSet ds = new DataSet();
            // Adapter fills the dataset.
            myAdapter.Fill(ds);
            // Places the data in the specified table.
            dataCustomerBooking.DataSource = ds.Tables[0];
        }

        // The delete button
        private void BTN_DELETE_Click(object sender, EventArgs e)
        {
            // Makes the Delete Customer Booking form a variable
            var DeleteBooking = new Delete_Customer_Booking();
            // Displays the form
            DeleteBooking.Show();
        }
    }
}
