﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Adventure_StaffApplicationMenu
{
    public partial class Delete_StorageItem : Form
    {
        // These properties help connect to
        // or use data from the database
        private string conn;
        private MySqlConnection connect;
        MySqlCommand cmd;
        private MySqlDataAdapter assetAdapter;
        private MySqlDataAdapter ingredientAdapter;
        private DataTable assetTable;
        private DataTable ingredientTable;
        public Delete_StorageItem()
        {
            // Initializes form
            InitializeComponent();
        }

        // Database Connection code
        private void db_connection()
        {
            // Connects to the database
            try
            {
                conn = "Server=localhost;Database=escape;Uid=root;Pwd=root;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        // Cancel button
        private void cancel_Click(object sender, EventArgs e)
        {
            // Closes form
            Close();
        }

        // Delete Stock item Button
        private void delete_StockItem_Click(object sender, EventArgs e)
        {
            // if statement, if choosen stock type == 0,
            // stock type is "Asset"
            if(choose_StockTypeDLT.SelectedIndex == 0)
            {
                // Deletes item from database
                // Connect to database
                db_connection();
                // Query deletes item from text input
                string query = "DELETE from escaperoom_assets where asset_id = '" + txt_StockID_DLT.Text + "'";
                // New command to activate the query
                cmd = new MySqlCommand(query, connect);
                // Prompt message
                MessageBox.Show("Delete Successful!");
                // Executes the command
                cmd.ExecuteNonQuery();
            }
            // else if statement, if choosen stock type == 1,
            // stock type is "Ingredient"
            else if (choose_StockTypeDLT.SelectedIndex == 1)
            {
                // Deletes item from database
                // Connect to database
                db_connection();
                // Query deletes item from text input
                string query = "DELETE from ingredients where ingredients_id = '" + txt_StockID_DLT.Text + "'";
                // New command to activate the query
                cmd = new MySqlCommand(query, connect);
                // Prompt message
                MessageBox.Show("Delete Successful!");
                // Executes the command
                cmd.ExecuteNonQuery();
            }
        }

        // Delete Storage Item Load
        private void Delete_StorageItem_Load(object sender, EventArgs e)
        {
            // Sets the dropdown options
            choose_StockTypeDLT.Items.Add("Asset");
            choose_StockTypeDLT.Items.Add("Ingredients");
        }

        // Choose Stock Type Selected Index
        private void choose_StockTypeDLT_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Chooses option
            // Connects to the database
            db_connection();
            // if statement, if choosen stock type = 0
            // Change data list to Assets
            if (choose_StockTypeDLT.SelectedIndex == 0)
            {
                // Disables the text boxes
                txt_StockTotal_DLT.Enabled = false;
                txt_StockCost_DLT.Enabled = false;
                // Enables this text box
                txt_StockStatus_DLT.Enabled = true;
                // Creates a new database command
                MySqlCommand cmd = new MySqlCommand();
                // Sets the query in the database command
                cmd.CommandText = "SELECT asset_id, asset_name, asset_status FROM escaperoom_assets";
                // Sets the connection for the database command
                cmd.Connection = connect;
                // Creates a new adapter to hold the asset data
                assetAdapter = new MySqlDataAdapter();
                // Set the MySql command for the adapter
                assetAdapter.SelectCommand = cmd;
                // Creates a new datatable
                assetTable = new DataTable();
                // Adapter fills the table
                assetAdapter.Fill(assetTable);
                // Dropdown gets the data from the table
                choose_StockItemDLT.DataSource = assetTable;
                // Displays the specified data
                choose_StockItemDLT.DisplayMember = "asset_name";
                // Identifies each item by id
                choose_StockItemDLT.ValueMember = "asset_id";
            }
            // else if statement, if choosen stock type = 0
            // Change data list to ingredients
            else if (choose_StockTypeDLT.SelectedIndex == 1)
            {
                // Enables the text boxes
                txt_StockTotal_DLT.Enabled = true;
                txt_StockCost_DLT.Enabled = true;
                // Disables this text boxe
                txt_StockStatus_DLT.Enabled = false;
                // Creates a new database command
                MySqlCommand cmd = new MySqlCommand();
                // Sets the query in the database command
                cmd.CommandText = "SELECT ingredients_id, ingredients_name, ingredients_cost, ingredient_stock FROM ingredients";
                // Sets the connection for the database command
                cmd.Connection = connect;
                // Creates a new adapter to hold the ingredient data
                ingredientAdapter = new MySqlDataAdapter();
                // Set the MySql command for the adapter
                ingredientAdapter.SelectCommand = cmd;
                // Creates a new datatable
                ingredientTable = new DataTable();
                // Adapter fills the table
                ingredientAdapter.Fill(ingredientTable);
                // Dropdown gets the data from the table
                choose_StockItemDLT.DataSource = ingredientTable;
                // Displays the specified data
                choose_StockItemDLT.DisplayMember = "ingredients_name";
                // Identifies each item by id
                choose_StockItemDLT.ValueMember = "ingredients_id";
                // close connection
                connect.Close();
            }
        }

        // Choose Stock Item Selected Index
        private void choose_StockItemDLT_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Changes data output
            // Connects to the database
            db_connection();
            // if statement, if choosen stock type = 0
            // Display asset data list
            if (choose_StockTypeDLT.SelectedIndex == 0)
            {
                // Creates new command to get data from query
                cmd = new MySqlCommand("SELECT * FROM escaperoom_assets where asset_name ='" + choose_StockItemDLT.Text + "'", connect);
                // Execute command
                cmd.ExecuteNonQuery();
                // Data reader for asset
                MySqlDataReader assetReader;
                // Command activates reader
                assetReader = cmd.ExecuteReader();
                // While statement for reader
                // Reads the input
                // Converts query column into strings
                // Textbox equals string
                while (assetReader.Read())
                {
                    string assetID = (string)assetReader["asset_id"].ToString();
                    txt_StockID_DLT.Text = assetID;

                    txt_StockType.Text = "Asset";

                    string assetName = (string)assetReader["asset_name"].ToString();
                    txt_StockName_DLT.Text = assetName;

                    string assetStatus = (string)assetReader["asset_status"].ToString();
                    txt_StockStatus_DLT.Text = assetStatus;

                    txt_StockTotal_DLT.Clear();
                    txt_StockCost_DLT.Clear();
                }
            }
            // else if statement, if choosen stock type = 0
            // Display ingredient data list
            else if (choose_StockTypeDLT.SelectedIndex == 1)
            {
                // Creates new command to get data from query
                cmd = new MySqlCommand("SELECT * FROM ingredients where ingredients_name ='" + choose_StockItemDLT.Text + "'", connect);
                // Execute command
                cmd.ExecuteNonQuery();
                // Data reader for ingredient
                MySqlDataReader ingreReader;
                // Command activates reader
                ingreReader = cmd.ExecuteReader();
                // While statement for reader
                // Reads the input
                // Converts query column into strings
                // Textbox equals string
                while (ingreReader.Read())
                {
                    string ingreID = (string)ingreReader["ingredients_id"].ToString();
                    txt_StockID_DLT.Text = ingreID;

                    txt_StockType.Text = "Ingredient";

                    string ingreName = (string)ingreReader["ingredients_name"].ToString();
                    txt_StockName_DLT.Text = ingreName;

                    string ingreStockTotal = (string)ingreReader["ingredient_stock"].ToString();
                    txt_StockTotal_DLT.Text = ingreStockTotal;

                    string ingreCost = (string)ingreReader["ingredients_cost"].ToString();
                    txt_StockCost_DLT.Text = ingreCost;

                    txt_StockStatus_DLT.Clear();
                }
            }
        }
    }
}
