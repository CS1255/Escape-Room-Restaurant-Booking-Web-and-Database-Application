﻿
namespace Adventure_StaffApplicationMenu
{
    partial class Customer_List_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Return_Button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.alpha = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.delete = new System.Windows.Forms.Button();
            this.BTN_SEARCH = new System.Windows.Forms.Button();
            this.table_Reload = new System.Windows.Forms.Button();
            this.BTN_cust_History = new System.Windows.Forms.Button();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataCustomerList = new System.Windows.Forms.DataGridView();
            this.txtCustomerList = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataCustomerList)).BeginInit();
            this.SuspendLayout();
            // 
            // Return_Button
            // 
            this.Return_Button.Location = new System.Drawing.Point(12, 12);
            this.Return_Button.Name = "Return_Button";
            this.Return_Button.Size = new System.Drawing.Size(124, 23);
            this.Return_Button.TabIndex = 17;
            this.Return_Button.Text = "Return to Options";
            this.Return_Button.UseVisualStyleBackColor = true;
            this.Return_Button.Click += new System.EventHandler(this.Return_Button_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 15);
            this.label2.TabIndex = 20;
            this.label2.Text = "Search:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 15);
            this.label3.TabIndex = 21;
            this.label3.Text = "Order By:";
            // 
            // alpha
            // 
            this.alpha.Location = new System.Drawing.Point(76, 184);
            this.alpha.Name = "alpha";
            this.alpha.Size = new System.Drawing.Size(89, 23);
            this.alpha.TabIndex = 22;
            this.alpha.Text = "Alphabetical";
            this.alpha.UseVisualStyleBackColor = true;
            this.alpha.Click += new System.EventHandler(this.alpha_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 234);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 15);
            this.label5.TabIndex = 23;
            this.label5.Text = "Customer Settings:";
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(14, 265);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(75, 23);
            this.delete.TabIndex = 26;
            this.delete.Text = "DELETE";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // BTN_SEARCH
            // 
            this.BTN_SEARCH.Location = new System.Drawing.Point(171, 144);
            this.BTN_SEARCH.Name = "BTN_SEARCH";
            this.BTN_SEARCH.Size = new System.Drawing.Size(75, 23);
            this.BTN_SEARCH.TabIndex = 27;
            this.BTN_SEARCH.Text = "Search";
            this.BTN_SEARCH.UseVisualStyleBackColor = true;
            this.BTN_SEARCH.Click += new System.EventHandler(this.BTN_SEARCH_Click);
            // 
            // table_Reload
            // 
            this.table_Reload.Location = new System.Drawing.Point(113, 265);
            this.table_Reload.Name = "table_Reload";
            this.table_Reload.Size = new System.Drawing.Size(95, 23);
            this.table_Reload.TabIndex = 34;
            this.table_Reload.Text = "Reload Table";
            this.table_Reload.UseVisualStyleBackColor = true;
            this.table_Reload.Click += new System.EventHandler(this.table_Reload_Click);
            // 
            // BTN_cust_History
            // 
            this.BTN_cust_History.Location = new System.Drawing.Point(14, 294);
            this.BTN_cust_History.Name = "BTN_cust_History";
            this.BTN_cust_History.Size = new System.Drawing.Size(131, 23);
            this.BTN_cust_History.TabIndex = 35;
            this.BTN_cust_History.Text = "Customer History";
            this.BTN_cust_History.UseVisualStyleBackColor = true;
            this.BTN_cust_History.Click += new System.EventHandler(this.BTN_cust_History_Click);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label4.Location = new System.Drawing.Point(305, 55);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(129, 21);
            this.Label4.TabIndex = 37;
            this.Label4.Text = "Customer Details";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label1.Location = new System.Drawing.Point(210, 12);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(337, 30);
            this.Label1.TabIndex = 36;
            this.Label1.Text = "ADVENTURE - Staff Application";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataCustomerList);
            this.groupBox2.Location = new System.Drawing.Point(284, 93);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(504, 345);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Customer Table";
            // 
            // dataCustomerList
            // 
            this.dataCustomerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataCustomerList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataCustomerList.Location = new System.Drawing.Point(3, 19);
            this.dataCustomerList.Name = "dataCustomerList";
            this.dataCustomerList.RowTemplate.Height = 25;
            this.dataCustomerList.Size = new System.Drawing.Size(498, 323);
            this.dataCustomerList.TabIndex = 1;
            // 
            // txtCustomerList
            // 
            this.txtCustomerList.Location = new System.Drawing.Point(76, 144);
            this.txtCustomerList.Name = "txtCustomerList";
            this.txtCustomerList.Size = new System.Drawing.Size(89, 23);
            this.txtCustomerList.TabIndex = 39;
            // 
            // Customer_List_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtCustomerList);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.BTN_cust_History);
            this.Controls.Add(this.table_Reload);
            this.Controls.Add(this.BTN_SEARCH);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.alpha);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Return_Button);
            this.Name = "Customer_List_Form";
            this.Text = "Customer_List_Form";
            this.Load += new System.EventHandler(this.Customer_List_Form_Load);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataCustomerList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button Return_Button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button alpha;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button BTN_SEARCH;
        private System.Windows.Forms.Button table_Reload;
        private System.Windows.Forms.Button BTN_cust_History;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataCustomerList;
        private System.Windows.Forms.TextBox txtCustomerList;
    }
}