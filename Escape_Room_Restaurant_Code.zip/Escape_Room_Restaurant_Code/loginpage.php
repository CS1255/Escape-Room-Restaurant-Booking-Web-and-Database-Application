<!-- Setting up connections -->
<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";
include "includes/debug.php";
?>
<!-- Start of Login Page Code -->
<!doctype html>
<html>
<head>
	<title> Website Test </title>
	
	<!-- Main Header -->
	<div class="header">
	  <h1>Adventure</h1>
	</div>
	
	<!-- Viewport and bootstrap code for site -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
	  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
	<!-- Styles for website -->
	<style>
	/* Site Body */
	body {
	  font-family: Arial;
	  padding: 10px;
	  background: #f1f1f1;
	}

	/* Header/Blog Title */
	.header {
	  padding: 30px;
	  text-align: center;
	  background: #ff751a;
	}
	
	/* Creates a singular column that spans the whole page */
	.column {
	  float: center;
	  text-align: center;
	  width: 100%;
	  padding: 15px;
	}
	
	/* Clear floats after the columns */
	.row:after {
	  content: "";
	  display: table;
	  clear: both;
	}
	
	/* Header for Title */
	.header h1 {
	  font-size: 50px;
	}
	</style>
</head>
<body>

<!-- Includes navigation -->
<div id="wrapper">
	<nav>
		<?php include "includes/nav.php"; ?>
	</nav>
</div>
	

<main>
<!-- Includes Login process -->
<div class="row">
	<!-- Column for Log in -->
	<div class="column">
	<div class="header">
		<h2>Log in</h2>
	</div>
	<header>
		<?php include "includes/header.php"; ?>
	</header>
	</div>
</div>

</main>



</body>
</html>

<!-- Includes Footer -->
<div id="wrapper">
	<footer>
		<?php include "includes/footer.php"; ?>
	</footer>
</div> <!-- End of Wrapper -->


</body>
</html>