<!-- Setting up connections -->
<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";
include "includes/debug.php";
?>
<!-- Start of Roomlist Page Code -->
<!doctype html>
<html>
<head>
	<title> Website Test </title>
	
	<!-- Main Header -->
	<div class="header">
	  <h1>Adventure</h1>
	</div>
	
	<!-- Viewport and bootstrap code for site -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		
	<!-- Styles for website -->
	<style>
	/* Site Body */
	body {
	  font-family: Arial;
	  padding: 10px;
	  background: #f1f1f1;
	}

	/* Header/Blog Title */
	.header {
	  padding: 30px;
	  text-align: center;
	  background: #ff751a;
	}

	/* Header for Title */
	.header h1 {
	  font-size: 50px;
	}
	
	/* Image settings */
	img {
	  float: left;
	  position: static;
	}
	
	/* escaperoom modal */
	#escaperoom {
	  width: 750px;
	  padding: 50px;
	  margin: 10px;
	}
	
	/* Creates a singular column that spans the whole page */
	.column {
	  float: center;
	  text-align: left;
	  width: 100%;
	  padding: 15px;
	}

	/* Clear floats after the columns */
	.row:after {
	  content: "";
	  display: table;
	  clear: both;
	}

	/* Gallery settings */
	div.gallery {
	  margin: 74px;
	  border: 1px solid #0066cc;
	  float: left;
	  width: 200px;
	  height: 275px;
	}

	/* When hovering over gallery */
	div.gallery:hover {
	  border: 1px solid #0066cc;
	}

	/* Gallery image settings */
	div.gallery img {
	  width: 100%;
	  height: auto;
	}

	/* Gallery description */
	div.desc {
	  padding: 15px;
	  text-align: center;
	}
	</style>
</head>
<body>

<!-- Includes navigation -->
<div id="wrapper">
	<nav>
		<?php include "includes/nav.php"; ?>
	</nav>
</div>
<main>
<div class="row">
<!-- Column for room list -->
	<div class="column">
		<div class="header">
			<h2>Our Escape Rooms</h2>
		</div>
	
		<!-- Alices Wonderland Escape Modal -->
		<div class="gallery">
		  <a target="_blank">
			<img src="escaperoomimages/HedgeMaze.jpg" alt="HedgeMaze" width="600" height="400" />
		  </a>
		  <div class="desc">Alice's Wonderland Escape - Click the button below to learn more!<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal1">Learn more!</button></div>
		  <!-- Modal -->
		  <div class="modal fade" id="myModal1" role="dialog">
			<div class="modal-dialog modal-lg">
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Alice's Wonderland Escape</h4>
				</div>
				<div class="modal-body">
					<div id="escaperoom">
						<form method="post" action="">
							<div class ="container">
								<img src="escaperoomimages/HedgeMaze.jpg" style="width:170px;height:170px;margin-right:10px;" alt="HedgeMaze" />
								<?php 
								echo $_SESSION['escaperoom_id'] = "1.";
								$query = "SELECT escaperoom_name, escaperoom_theme, escaperoom_difficulty, escaperoom_adult_price, escaperoom_child_price, escaperoom_size, escaperoom_playeramount FROM escape_room WHERE escaperoom_id = 1";
								$result = mysqli_query ($con, $query);
								$row = mysqli_fetch_array ($result);
								?>
									<label for="escaperoomname">Escape Room:</label>
									<input type="text" name="escaperoomname" id="escaperoomname" value="<?php echo $row['escaperoom_name'];?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Theme:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_theme']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomdiff">Difficulty:</label>
									<input type="text" name="escaperoomdiff" id="escaperoomdiff" value="<?php echo $row['escaperoom_difficulty']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomadultprice">Adult Price:</label>
									<input type="text" name="escaperoomadultprice" id="escaperoomadultprice" value="<?php echo $row['escaperoom_adult_price']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomchildprice">Child Price:</label>
									<input type="text" name="escaperoomchildprice" id="escaperoomchildprice" value="<?php echo $row['escaperoom_child_price']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomsize">Size:</label>
									<input type="text" name="escaperoomsize" id="escaperoomsize" value="<?php echo $row['escaperoom_size']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomamount">Max Player Amount:</label>
									<input type="text" name="escaperoomamount" id="escaperoomamount" value="<?php echo $row['escaperoom_playeramount']; ?>">
									<?php
										if ($_SESSION['loggedin']) {
											echo "<button class=\"button button1\"><a href=\"makebooking.php\">Book this room?</a></button> <!-- Only when logged in -->";
										}
									?>
							</div>
						</form>
					</div>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div>   
		</div>

		<!-- Merlins Tower Modal -->
		<div class="gallery">
		  <a target="_blank" href="escaperoomimages/WizardRoom.jpg">
			<img src="escaperoomimages/WizardRoom.jpg" alt="WizardRoom" width="600" height="400" />
		  </a>
		  <div class="desc">Merlin's Tower - Click the button below to learn more!<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal2">Learn more!</button></div>
		  <!-- Modal -->
		  <div class="modal fade" id="myModal2" role="dialog">
			<div class="modal-dialog modal-lg">
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Merlin's Tower</h4>
				</div>
				<div class="modal-body">
					<div id="escaperoom">
						<form method="post" action="">
							<div class ="container">
								<img src="escaperoomimages/WizardRoom.jpg" style="width:170px;height:170px;margin-right:10px;" alt="WizardRoom" />
								<?php 
								echo $_SESSION['escaperoom_id'] = "2.";
								$query = "SELECT escaperoom_name, escaperoom_theme, escaperoom_difficulty, escaperoom_adult_price, escaperoom_child_price, escaperoom_size, escaperoom_playeramount FROM escape_room WHERE escaperoom_id = 2";
								$result = mysqli_query ($con, $query);
								$row = mysqli_fetch_array ($result);
								?>
									<label for="escaperoomname">Escape Room:</label>
									<input type="text" name="escaperoomname" id="escaperoomname" value="<?php echo $row['escaperoom_name']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Theme:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_theme']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Difficulty:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_difficulty']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Adult Price:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_adult_price']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Child Price:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_child_price']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Size:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_size']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Max Player Amount:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_playeramount']; ?>">
									<?php
										if ($_SESSION['loggedin']) {
											echo "<button class=\"button button1\"><a href=\"makebooking.php\">Book this room?</a></button> <!-- Only when logged in -->";
										}
									?>
							</div>
						</form>
					</div>  
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div> 
		</div>

		<!-- Space Ship Escape Modal -->
		<div class="gallery">
		  <a target="_blank" href="escaperoomimages/SpaceShipRoom.jpg">
			<img src="escaperoomimages/SpaceShipRoom.jpg" alt="SpaceShipRoom" width="600" height="400" />
		  </a>
		  <div class="desc">Space Ship Escape - Click the button below to learn more!<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal3">Learn more!</button></div>
		  <!-- Modal -->
		  <div class="modal fade" id="myModal3" role="dialog">
			<div class="modal-dialog modal-lg">
			
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Space Ship Escape</h4>
				</div>
				<div class="modal-body">
					<div id="escaperoom">
						<form method="post" action="">
							<div class ="container">
								<img src="escaperoomimages/SpaceShipRoom.jpg" style="width:170px;height:170px;margin-right:10px;" alt="SpaceShipRoom" />
								<?php 
								echo $_SESSION['escaperoom_id'] = "3.";
								$query = "SELECT escaperoom_name, escaperoom_theme, escaperoom_difficulty, escaperoom_adult_price, escaperoom_child_price, escaperoom_size, escaperoom_playeramount FROM escape_room WHERE escaperoom_id = 3";
								$result = mysqli_query ($con, $query);
								$row = mysqli_fetch_array ($result);
								?>
									<label for="escaperoomname">Escape Room:</label>
									<input type="text" name="escaperoomname" id="escaperoomname" value="<?php echo $row['escaperoom_name']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Theme:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_theme']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Difficulty:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_difficulty']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Adult Price:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_adult_price']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Child Price:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_child_price']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Size:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_size']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Max Player Amount:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_playeramount']; ?>">
									<?php
										if ($_SESSION['loggedin']) {
											echo "<button class=\"button button1\"><a href=\"makebooking.php\">Book this room?</a></button> <!-- Only when logged in -->";
										}
									?>
							</div>
						</form>
					</div>  
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div> 
		</div>

		<!-- Curse of the Pharaoh Modal -->
		<div class="gallery">
		  <a target="_blank" href="escaperoomimages/EgyptianTomb.jpg">
			<img src="escaperoomimages/EgyptianTomb.jpg" alt="EgyptianTomb" width="600" height="400" />
		  </a>
		  <div class="desc">Curse of the Pharaoh - Click the button below to learn more!<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal4">Learn more!</button></div>
		  <!-- Modal -->
		  <div class="modal fade" id="myModal4" role="dialog">
			<div class="modal-dialog modal-lg">
			
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Curse of the Pharaoh</h4>
				</div>
				<div class="modal-body">
					<div id="escaperoom">
						<form method="post" action="">
							<div class ="container">
								<img src="escaperoomimages/EgyptianTomb.jpg" style="width:170px;height:170px;margin-right:10px;" alt="EgyptianTomb" />
								<?php 
								echo $_SESSION['escaperoom_id'] = "4.";
								$query = "SELECT escaperoom_name, escaperoom_theme, escaperoom_difficulty, escaperoom_adult_price, escaperoom_child_price, escaperoom_size, escaperoom_playeramount FROM escape_room WHERE escaperoom_id = 4";
								$result = mysqli_query ($con, $query);
								$row = mysqli_fetch_array ($result);
								?>
									<label for="escaperoomname">Escape Room:</label>
									<input type="text" name="escaperoomname" id="escaperoomname" value="<?php echo $row['escaperoom_name']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Theme:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_theme']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Difficulty:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_difficulty']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Adult Price:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_adult_price']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Child Price:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_child_price']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Size:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_size']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Max Player Amount:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_playeramount']; ?>">
									<?php
										if ($_SESSION['loggedin']) {
											echo "<button class=\"button button1\"><a href=\"makebooking.php\">Book this room?</a></button> <!-- Only when logged in -->";
										}
									?>
							</div>
						</form>
					</div>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div> 
		</div>
		
		<!-- The Hunt for Treasure Island Modal -->
		<div class="gallery">
		  <a target="_blank" href="escaperoomimages/PirateRoom.jpg">
			<img src="escaperoomimages/PirateRoom.jpg" alt="PirateRoom" width="600" height="400" />
		  </a>
		  <div class="desc">The Hunt for Treasure Island - Click the button below to learn more!<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal5">Learn more!</button></div>
		  <!-- Modal -->
		  <div class="modal fade" id="myModal5" role="dialog">
			<div class="modal-dialog modal-lg">
			
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">The Hunt for Treasure Island</h4>
				</div>
				<div class="modal-body">
					<div id="escaperoom">
						<form method="post" action="">
							<div class ="container">
								<img src="escaperoomimages/PirateRoom.jpg" style="width:170px;height:170px;margin-right:10px;" alt="PirateRoom" />
								<?php 
								echo $_SESSION['escaperoom_id'] = "5.";
								$query = "SELECT escaperoom_name, escaperoom_theme, escaperoom_difficulty, escaperoom_adult_price, escaperoom_child_price, escaperoom_size, escaperoom_playeramount FROM escape_room WHERE escaperoom_id = 5";
								$result = mysqli_query ($con, $query);
								$row = mysqli_fetch_array ($result);
								?>
									<label for="escaperoomname">Escape Room:</label>
									<input type="text" name="escaperoomname" id="escaperoomname" value="<?php echo $row['escaperoom_name']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Theme:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_theme']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Difficulty:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_difficulty']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Adult Price:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_adult_price']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Child Price:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_child_price']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Size:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_size']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Max Player Amount:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_playeramount']; ?>">
									<?php
										if ($_SESSION['loggedin']) {
											echo "<button class=\"button button1\"><a href=\"makebooking.php\">Book this room?</a></button> <!-- Only when logged in -->";
										}
									?>
							</div>
						</form>
					</div>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div> 
		</div>
		
		<!-- Agents: The Impossible Mission Modal -->
		<div class="gallery">
		  <a target="_blank" href="escaperoomimages/SpyMission.jpg">
			<img src="escaperoomimages/SpyMission.jpg" alt="SpyMission" width="600" height="400" />
		  </a>
		  <div class="desc">Agents: The Impossible Mission - Click the button below to learn more!<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal6">Learn more!</button></div>
		  <!-- Modal -->
		  <div class="modal fade" id="myModal6" role="dialog">
			<div class="modal-dialog modal-lg">
			
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Agents: The Impossible Mission</h4>
				</div>
				<div class="modal-body">
					<div id="escaperoom">
						<form method="post" action="">
							<div class ="container">
								<img src="escaperoomimages/SpyMission.jpg" style="width:170px;height:170px;margin-right:10px;" alt="SpyMission" />
								<?php 
								echo $_SESSION['escaperoom_id'] = "6.";
								$query = "SELECT escaperoom_name, escaperoom_theme, escaperoom_difficulty, escaperoom_adult_price, escaperoom_child_price, escaperoom_size, escaperoom_playeramount FROM escape_room WHERE escaperoom_id = 6";
								$result = mysqli_query ($con, $query);
								$row = mysqli_fetch_array ($result);
								?>
									<label for="escaperoomname">Escape Room:</label>
									<input type="text" name="escaperoomname" id="escaperoomname" value="<?php echo $row['escaperoom_name']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Theme:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_theme']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Difficulty:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_difficulty']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Adult Price:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_adult_price']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Child Price:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_child_price']; ?>">
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Size:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_size']; ?>">
									<p></p>
									&nbsp;&nbsp;&nbsp;
									<label for="escaperoomtheme">Max Player Amount:</label>
									<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_playeramount']; ?>">
									<?php
										if ($_SESSION['loggedin']) {
											echo "<button class=\"button button1\"><a href=\"makebooking.php\">Book this room?</a></button> <!-- Only when logged in -->";
										}
									?>
							</div>
						</form>
					</div>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div> 
		</div>
	</div> 
</div>
</main>

<!-- Includes Footer -->
<div id="wrapper">
	<footer>
		<?php include "includes/footer.php"; ?>
	</footer>
</div>

</body>
</html>