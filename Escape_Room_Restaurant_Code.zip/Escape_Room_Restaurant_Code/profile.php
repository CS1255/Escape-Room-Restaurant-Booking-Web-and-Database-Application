<!-- Setting up connections -->
<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";
include "includes/debug.php";

// Only when logged in
// Get data from customer table
if ($_SESSION['loggedin']) {	

	$query = "SELECT customer_firstname, customer_surname, customer_email, customer_comment from customer WHERE customer_id = {$_SESSION['id']}";
	
	$result = mysqli_query ($con, $query);
	
	$row = mysqli_fetch_array ($result);
	
} else {
	header ("Location: index.php");
}
?>
<!-- Start of Profile Page Code -->
<!doctype html>
<html>
<head>
	<title> Website Test </title>
	
	<!-- Main Header -->
	<div class="header">
	  <h1>Adventure</h1>
	</div>
	
	<!-- Viewport and bootstrap code for site -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
	<!-- Styles for website -->
	<style>
	/* Site Body */
	body {
	  font-family: Arial;
	  padding: 10px;
	  background: #f1f1f1;
	}

	/* Header/Blog Title */
	.header {
	  padding: 30px;
	  text-align: center;
	  background: #ff751a;
	}

	/* Header for Title */
	.header h1 {
	  font-size: 50px;
	}
	
	/* Creates a singular column that spans the whole page */
	.column {
	  float: center;
	  text-align: center;
	  width: 100%;
	  padding: 15px;
	}
	
	/* Clear floats after the columns */
	.row:after {
	  content: "";
	  display: table;
	  clear: both;
	}
	
	/* Sets textarea size */
	textarea {
	width: 289px;
	height: 100px;
	}
	</style>
</head>
<body>

<!-- Includes navigation -->
<div id="wrapper">
	<nav>
		<?php include "includes/nav.php"; ?>
	</nav>
</div>
<main>
<div class="row">
	<!-- Column for Profile -->
	<div class="column">
		<div class="header">
			<h2>Your Profile</h2>
		</div>
		<br></br>
		<!-- Form for profile and update -->
		<div id="profileForm">
			<form method="post" action="profile_process.php">
				<label for="firstname">Your Firstname:</label>
				&nbsp;
				<input type="text" name="firstname" id="firstname" value="<?php echo $row['customer_firstname']; ?>">
				&nbsp;&nbsp;&nbsp;
				<label for="surname">Your Surname:</label>
				&nbsp;
				<input type="text" name="surname" id="surname" value="<?php echo $row['customer_surname']; ?>">
				&nbsp;&nbsp;&nbsp;
				<label for="email">Your email:</label>
				&nbsp;
				<input type="email" name="email" id="email" value="<?php echo $row['customer_email']; ?>">
				<p></p>
				<label for="comment">Comment:</label>
				<p></p>
				<textarea name="comment" id="comment"><?php echo $row['customer_comment']; ?></textarea>	
				<br></br>
				<label for="update">&nbsp;</label>
				<input type="submit" name="update" value="Update Profile">
			</form>
		</div>
	</div>
</div>
</main>

<!-- Includes Footer -->
<div id="wrapper">
	<footer>
		<?php include "includes/footer.php"; ?>
	</footer>
</div> <!-- End of Wrapper -->


</body>
</html>