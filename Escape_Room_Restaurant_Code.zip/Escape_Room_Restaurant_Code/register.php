<!-- Setting up connections -->
<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";
include "includes/debug.php";
?>
<!-- Start of Register Page Code -->
<!doctype html>
<html>
<head>
	<title> Website Test </title>
	
	<!-- Main Header -->
	<div class="header">
	  <h1>Adventure</h1>
	</div>
	
	<!-- Viewport and bootstrap code for site -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		
	<!-- Styles for website -->
	<style>
	/* Site Body */
	body {
	  font-family: Arial;
	  padding: 10px;
	  background: #f1f1f1;
	}

	/* Header/Blog Title */
	.header {
	  padding: 30px;
	  text-align: center;
	  background: #ff751a;
	}

	/* Header for Title */
	.header h1 {
	  font-size: 50px;
	}
	
	/* Creates a singular column that spans the whole page */
	.column {
	  float: center;
	  text-align: center;
	  width: 100%;
	  padding: 15px;
	}

	/* Clear floats after the columns */
	.row:after {
	  content: "";
	  display: table;
	  clear: both;
	}
	</style>
</head>
<body>

<div id="wrapper">
	<nav>
		<?php include "includes/nav.php"; ?>
	</nav>
</div> <!-- End of Wrapper -->

<main>
<div class="row">
	<!-- Register an account -->
	<div class="column">
		<div class="header">
			<h2>Register</h2>
		</div>
		<br></br>
		<!-- Display error message -->
		<div id="ErrorMessage">
			<?php
				echo $_SESSION['errorMessage'];
			?>
		</div>
		<!-- Form for registration -->
		<div id="registerForm">
			<form method="post" action="register_process.php">
				<label for="username">Pick Your Username:</label>
				&nbsp;
				<input type="text" name="username" id="username" placeholder="Your username" value="<?php echo $_SESSION['username']; ?>">
				&nbsp;&nbsp;&nbsp;
				<label for="password">Pick Your Password:</label>
				&nbsp;
				<input type="text" name="password" id="password" placeholder="Your password">
				&nbsp;&nbsp;&nbsp;
				<label for="passwordC">Confirm your password:</label>
				&nbsp;
				<input type="text" name="passwordC" id="passwordC" placeholder="Confirm Password">
				<p></p>
				<label for="firstname">Your Firstname:</label>
				&nbsp;
				<input type="text" name="firstname" id="firstname" placeholder="Your firstname" value="<?php echo $_SESSION['firstname']; ?>">
				&nbsp;&nbsp;&nbsp;
				<label for="surname">Your Surname:</label>
				&nbsp;
				<input type="text" name="surname" id="surname" placeholder="Your surname" value="<?php echo $_SESSION['surname']; ?>">
				<p></p>
				<label for="email">Your email:</label>
				&nbsp;
				<input type="text" name="email" id="email" placeholder="Your email" value="<?php echo $_SESSION['email']; ?>">
				&nbsp;&nbsp;&nbsp;
				<label for="phone">Your phone:</label>
				&nbsp;
				<input type="text" name="phone" id="phone" placeholder="Your phone" value="<?php echo $_SESSION['phone']; ?>">
				<br></br>
				<label for="submit">&nbsp;</label>
				<input type="submit" name="submit" value="Register">
			</form>
		</div>
	</div>
</div>
</main>

<!-- Includes Footer -->
<div id="wrapper">
	<footer>
		<?php include "includes/footer.php"; ?>
	</footer>
</div> <!-- End of Wrapper -->
</body>
</html>


	