<?php
// start session, connect to database
session_start();
include "includes/connect.php";
$_SESSION['errorMessage'] = "";

// Stores the data from the form for later use
$_SESSION['escaperoomname'] = $_POST['escaperoomname'];
$_SESSION['escaperoomtheme'] = $_POST['escaperoomtheme'];
$_SESSION['escaperoomdiff'] = $_POST['escaperoomdiff'];
$_SESSION['escaperoomadultprice'] = $_POST['escaperoomadultprice'];
$_SESSION['escaperoomchildprice'] = $_POST['escaperoomchildprice'];
$_SESSION['escaperoomsize'] = $_POST['escaperoomsize'];

$_SESSION['totaladults'] = $_POST['totaladults'];
$_SESSION['totalchildren'] = $_POST['totalchildren'];
$_SESSION['totalprice'] = $_POST['totalprice'];

$_SESSION['firstname'] = $_POST['firstname'];
$_SESSION['surname'] = $_POST['surname'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['phone'] = $_POST['phone'];

// Checks if the text fields are empty.
if ($_POST['escaperoomname'] == "") $_SESSION['errorMessage'] .= "<p>Please choose an escape room</p>";
if ($_POST['escaperoomtheme'] == "") $_SESSION['errorMessage'] .= "";
if ($_POST['escaperoomdiff'] == "") $_SESSION['errorMessage'] .= "";
if ($_POST['escaperoomsize'] == "") $_SESSION['errorMessage'] .= "";

if ($_POST['totaladults'] == "") $_SESSION['errorMessage'] .= "<p>Please enter a number</p>";
if ($_POST['totalchildren'] == "") $_SESSION['errorMessage'] .= "";
if ($_POST['totalprice'] == "") $_SESSION['errorMessage'] .= "<p>Please select an escape room or/and enter the total adults/children you'll be bringing</p>";

// Data labels made from form input
$escape_name = $_POST['escaperoomname'];
$escape_theme = $_POST['escaperoomtheme'];
$escape_diff = $_POST['escaperoomdiff'];
$escape_roomsize = $_POST['escaperoomsize'];
$escape_totaladult = $_POST['totaladults'];
$escape_totalchild = $_POST['totalchildren'];
$escape_totalprice = $_POST['totalprice'];
		
$custFirstname = $_POST['firstname'];
$custSurname = $_POST['surname'];
$custEmail = $_POST['email'];
$custPhone = $_POST['phone'];

// INSERT query to add booking.
$query = "INSERT INTO bookings_list(custBooking_firstName, custBooking_surName, 
			custBooking_email, custBooking_phone, custBooking_escName, 
			custBooking_escTheme, custBooking_escDiff, custBooking_escRoomSize, 
			custBooking_totAdult, custBooking_totChild, custBooking_totPrice) 
			values('$custFirstname', '$custSurname', '$custEmail', 
			'$custPhone', '$escape_name', '$escape_theme', '$escape_diff', 
			'$escape_roomsize', '$escape_totaladult', '$escape_totalchild', '$escape_totalprice')";

//Checks to see if booking was successful or not.
if (mysqli_query($con, $query)) {
	//If successful, echo this message.
	echo "Booking successful";
}
else {
	//If failed, echo this message and display query.
	echo "Booking failed: " . $query . "<br>" . mysqli_error($con);
}
?>