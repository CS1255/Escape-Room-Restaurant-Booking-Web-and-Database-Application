<?php
// This code is in includes/functions.php

function trimInput($text, $maxChar = 0) {
	// if $maxChar is 0 don't trim the string
	if ($maxChar == 0) return $text;
	
	// if the $text is shorter than $maxChar don't
	// trim the string
	if (strlen($text) <= $maxChar) return $text;
	
	// The string is too long so trim and return
	return substr($text, 0, $maxChar);	
}


?>