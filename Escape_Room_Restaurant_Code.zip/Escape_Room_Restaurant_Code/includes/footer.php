<!-- A recurring style for each page -->
<style>
/* Style the footer */
.footer {
  padding: 15px;
  position:fixed;
  bottom: 0;
  width: 100%;
  text-align: center;
  background: #ddd;
  margin-top: 20px;
}
</style>

<?php
	if ($showTables) echo displayTables ($con);
?>
<!-- footer message -->
	<div class="footer">
		<h2>© 2021 ADVENTURE SID: 1801710</h2>
	</div>