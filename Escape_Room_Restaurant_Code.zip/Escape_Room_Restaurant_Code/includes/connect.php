<?php
// Description: Connects code to the escape database
$host = "localhost";
$db = "escape";
$user = "root";
$pass = "root";


$con = mysqli_connect($host, $user, $pass, $db);
?>