<!-- Login form -->
<div class="row">
	<div class="column">
		<br></br>
		<div id="logInForm">
			<?php
				if (!$_SESSION['loggedin']) {
			?>	
			<form method="post" action="login_process.php">
			<input type="text" id="username" name="username" placeholder="username">
			<input type="password" id="password" name="password" placeholder="password">
			<input type="submit" id="submit" name="submit" value="Log In">
		</form>
			<?php
				}
			?>
		</div>
		<?php 
			if ($debugOn) echo debugMessage($con); 
			if ($showTables) echo displayTables($con); 
		?>
	</div>
</div>
