<!-- Style for Navigation Bar -->
<style>
	ol {
	  list-style-type: none;
	  margin: 0;
	  padding: 0;
	  overflow: hidden;
	  background-color: #0066cc;
	}
	
	ol a {
	  list-style-type: none;
	  margin: 0;
	  padding: 0;
	  overflow: hidden;
	  float: center;
	}

	li a {
	  display: block;
	  color: white;
	  text-align: center;
	  padding: 14px 16px;
	  text-decoration: none;
	  float: left;
	}
	
	li a:hover:not(.active) {
	  background-color: #000066;
	}

	.active {
	  background-color: #cc5200;
	}
</style>

<!-- Navigation Bar options -->
<ol>
	<!-- Makes navbar option active based on current page -->
	<li><a class="<?php echo (basename($_SERVER['PHP_SELF']) == "index.php")?"active":"";?>" href ="index.php"> Home </a></li> 
	<li><a class="<?php echo (basename($_SERVER['PHP_SELF']) == "roomlist.php")?"active":"";?>" href="roomlist.php">Our Escape Rooms</a></li>
	<li><a class="<?php echo (basename($_SERVER['PHP_SELF']) == "restaurant.php")?"active":"";?>" href="restaurant.php">Our Restaurant</a></li>
	
	<!-- When logged in as a Customer -->
	<?php
		if ($_SESSION['loggedin']) {
			// Checks if current page matches self
			if(basename($_SERVER['PHP_SELF']) == "makebooking.php") {
				// Makes page active
				echo "<li><a class=\"active\" href=\"makebooking.php\">Make a booking!</a></li> <!-- Only when logged in -->";
			} else {
				// Non-active
				echo "<li><a href=\"makebooking.php\">Make a booking!</a></li> <!-- Only when logged in -->";
			}	
		}
	?>
	
	<!-- When logged in as a Customer -->
	<?php
		if ($_SESSION['loggedin']) {
			// Checks if current page matches self
			if(basename($_SERVER['PHP_SELF']) == "makeorder.php") {
				// Makes page active
				echo "<li><a class=\"active\" href=\"makeorder.php\">Make an order!</a></li> <!-- Only when logged in -->";
			} else {
				// Non-active
				echo "<li><a href=\"makeorder.php\">Make an order!</a></li> <!-- Only when logged in -->";
			}			
		}
	?>
	
	<!-- When logged in as a Customer -->
	<?php
		if ($_SESSION['loggedin']) {
			// Checks if current page matches self
			if(basename($_SERVER['PHP_SELF']) == "profile.php") {
				// Makes page active
				echo "<li><a class=\"active\" href=\"profile.php\">Profile</a></li> <!-- Only when logged in -->";
			} else {
				// Non-active
				echo "<li><a href=\"profile.php\">Profile</a></li> <!-- Only when logged in -->";
			}	
			
		}
	?>
	
	<!-- When logged in as a Customer -->
	<?php
		if ($_SESSION['loggedin']){
			echo "<li><a href =\"logout_process.php\">Logout</a></li> <!-- Only when logged in -->"; 
		}
	?>
	
	<!-- When logged out -->
	<?php
		if (!$_SESSION['loggedin']) {
			// Checks if current page matches self
			if(basename($_SERVER['PHP_SELF']) == "loginpage.php") {
				// Makes page active
				echo "<li><a class=\"active\" href=\"loginpage.php\">Login!</a></li> <!-- Only when logged out -->";
			} else {
				// Non-active
				echo "<li><a href=\"loginpage.php\">Login!</a></li> <!-- Only when logged out -->";
			}
		}
	?>
	
	<!-- When logged out -->
	<?php
		if (!$_SESSION['loggedin']) {
			// Checks if current page matches self
			if(basename($_SERVER['PHP_SELF']) == "register.php") {
				// Makes page active
				echo "<li><a class=\"active\" href=\"register.php\">Register an account</a></li> <!-- Only when logged out -->";
			} else {
				// Non-active
				echo "<li><a href=\"register.php\">Register an account</a></li> <!-- Only when logged out -->";
			}	
		}
	?>
</ol>