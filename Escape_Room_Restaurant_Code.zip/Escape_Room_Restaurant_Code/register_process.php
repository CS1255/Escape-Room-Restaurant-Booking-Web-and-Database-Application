<?php
// start session, connect to database
session_start();
include "includes/connect.php";
$_SESSION['errorMessage'] = "";

// Stores the data from the form for later use
$_SESSION['username'] = $_POST['username'];
$_SESSION['firstname'] = $_POST['firstname'];
$_SESSION['surname'] = $_POST['surname'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['phone'] = $_POST['phone'];

// Checks the fields are not empty
if ($_POST['username'] == "") $_SESSION['errorMessage'] .= "<p>Your must enter a username</p>";
if ($_POST['password'] == "") $_SESSION['errorMessage'] .= "<p>Your must enter a password</p>";
if ($_POST['passwordC'] == "") $_SESSION['errorMessage'] .= "<p>Your must enter a password confirmation</p>";
if ($_POST['firstname'] == "") $_SESSION['errorMessage'] .= "<p>Your must enter a firstname</p>";
if ($_POST['surname'] == "") $_SESSION['errorMessage'] .= "<p>Your must enter a surname</p>";
if ($_POST['email'] == "") $_SESSION['errorMessage'] .= "<p>Your must enter a email</p>";
if ($_POST['phone'] == "") $_SESSION['errorMessage'] .= "<p>Your must enter a phone</p>";

// Checked the passwords match
if ($_POST['password'] != $_POST['passwordC'])
	$_SESSION['errorMessage'] .= "<p>Your password and the confirmation do not match</p>";

// Checks the username is unique
$query = "SELECT COUNT(customer_username) FROM customer WHERE customer_username = '{$_POST['username']}'";

$result = mysqli_query ($con, $query);

$row = mysqli_fetch_array ($result);

$numOfUsers = $row['COUNT(customer_username)'];

if ($numOfUsers != 0)
	$_SESSION['errorMessage'] .= "<p>Please choose another username</p>";

// if the error message is no longer empty
// return to the form
if(isset($_POST['submit'])){
	// Checks if fields are empty
	if(!empty($_POST['username']) && !empty($_POST['password']) && !empty($_POST['passwordC']) && !empty($_POST['firstname']) && !empty($_POST['surname']) && !empty($_POST['email']) && !empty($_POST['phone']) && ($numOfUsers <= 0)) {
		// Data labels made from form input
		$username = $_POST['username'];
		$password = $_POST['password'];
		$firstname = $_POST['firstname'];
		$surname = $_POST['surname'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		// INSERT query to register customer
		$query = "INSERT INTO customer(customer_username, customer_password, customer_firstname, customer_surname, customer_email, customer_phone) values('$username', '$password', '$firstname', '$surname', '$email', '$phone')";
		
		$run = mysqli_query($con, $query) or die(mysqli_error());
		
		//Checks everything went well
		if($run){
			// Registration worked
			echo "Registration Successful";
		}
		else {
			// Registration didn't work
			echo "Registration Failed";
		}
	}
	// if fields are empty
	else {
		// Display error message.
		if ($_SESSION['errorMessage'] != "")
		header ("Location: register.php");
	}
}
?>