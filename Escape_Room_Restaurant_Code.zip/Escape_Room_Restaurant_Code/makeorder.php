<!-- Setting up connections -->
<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";
include "includes/debug.php";
?>
<!-- Start of Order Page Code -->
<!doctype html>
<html>
<head>
	<title> Website Test </title>
	
	<!-- Main Header -->
	<div class="header">
	  <h1>Adventure</h1>
	</div>
	
	<!-- Viewport and bootstrap code for site -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="../lib/w3.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
	<!-- Styles for website -->
	<style>
	/* Site Body */
	body {
	  font-family: Arial;
	  padding: 10px;
	  background: #f1f1f1;
	}

	/* Puts the Header at the top of the page */
	.header {
	  padding: 30px;
	  text-align: center;
	  background: #ff751a;
	}

	/* Header for Title */
	.header h1 {
	  font-size: 50px;
	}
	
	/* Creates a singular column that spans the whole page */
	.column {
	  float: center;
	  text-align: center;
	  width: 100%;
	  padding: 15px;
	}

	/* Clear floats after the columns */
	.row:after {
	  content: "";
	  display: table;
	  clear: both;
	}
	
	/* Button */
	.button {
	  background-color: white; 
	  color: white; 
	  border: 2px solid black;
	}

	/* Button Hover*/
	.button:hover {
	  background-color: #4CAF50;
	  color: white;
	}

	/* Button Active */
	.active {
	  background-color: #4CAF50;
	}
	
	/* Sets textarea size */
	textarea {
	width: 289px;
	height: 100px;
	}

	</style>
	
	<!-- Script to get/set food information -->
		<script>
		function fd_id(id) {
		  if (id == "") {

		  } else {
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				var parts = xmlhttp.responseText.split('|');
				document.getElementById("foodname").value = parts[0];
				document.getElementById("fd_option").value;
				
				document.getElementById("foodprice").value = parts[1];
				document.getElementById("fd_option").value;
				
				document.getElementById("foodtype").value = parts[2];
				document.getElementById("fd_option").value;
			  }
			};
			xmlhttp.open("GET","foodphp.php?id="+id,true);
			xmlhttp.send();
		  }
		  var xhttp = new XMLHttpRequest();

		}
		</script>
</head>
<body class="w3-container">

<!-- Includes navigation -->
<div id="wrapper">
	<nav>
		<?php include "includes/nav.php"; ?>
	</nav>
</div>
<main>
<div class="row">
	<!-- Column for Make an order / customer information -->
	<div class="column">
		<div class="header">
			<h2>Make an Order / Customer Information</h2>	
		</div>
		<!-- Display error message -->
		<div id="ErrorMessage">
			<?php
				echo $_SESSION['errorMessage'];
			?>
		</div>
		
		<!-- Form for orders -->
		<div id="ordercustomerForm">
			<form method="post" action="order_process.php">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				
				<!-- Displays food data -->
				<h4> Food Information </h4>	
				<div class="select-box">
				<label for="foodname">Food:</label>
				<?php
					$query = "SELECT * FROM food";
					$result1 = mysqli_query($con, $query);			
				?>
				<select id="fd_option" onchange="fd_id(this.value)">
					<option value="" selected disabled>Choose a meal</option>
				<?php while ($row = mysqli_fetch_array($result1)):;?>
					<option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
				<?php endwhile;?>

				</select>
				&nbsp;
				<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">	
				<p></p>
				<label for="foodprice">Food Price:</label>
				&nbsp;
				<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<label for="foodtype">Food Type:</label>
				&nbsp;
				<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
				</div>
				<br></br><br></br>

				<!-- Displays customer data -->
				<h4> Customer Information </h4>			
				<?php
					if ($_SESSION['loggedin']) {	

					$query = "SELECT customer_firstname, customer_surname, customer_email, customer_phone, customer_comment from customer WHERE customer_id = {$_SESSION['id']}";
									
					$result2 = mysqli_query ($con, $query);
									
					$row = mysqli_fetch_array ($result2);
									
					} else {
						header ("Location: index.php");
					}
				?>
				<label for="firstname">Your Firstname:</label>
				&nbsp;
				<input type="text" name="firstname" id="firstname" value="<?php echo $row['customer_firstname']; ?>">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<label for="surname">Your Surname:</label>
				&nbsp;
				<input type="text" name="surname" id="surname" value="<?php echo $row['customer_surname']; ?>">
				<p></p>
				<label for="email">Your email:</label>
				&nbsp;
				<input type="email" name="email" id="email" value="<?php echo $row['customer_email']; ?>">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<label for="phone">Your Phone:</label>
				&nbsp;
				<input type="phone" name="phone" id="phone" value="<?php echo $row['customer_phone']; ?>">
				<p></p>
				<label for="comment">Comment:</label>
				<p></p>
				<textarea name="comment" id="comment"><?php echo $row['customer_comment']; ?></textarea>
				<br></br>
				<input type="submit" name="submit" value="Make Order">
			</form>
		</div>
	</div>
</div>
</main>

<!-- Includes Footer -->
<div id="wrapper">
	<footer>
		<?php include "includes/footer.php"; ?>
	</footer>
</div> <!-- End of Wrapper -->
</body>
</html>