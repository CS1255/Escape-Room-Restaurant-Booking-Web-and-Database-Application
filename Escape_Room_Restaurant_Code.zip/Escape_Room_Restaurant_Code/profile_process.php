<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";

// Get data from the form	
echo $_POST['firstname'];
echo "<br>";
echo $_POST['surname'];
echo "<br>";
echo $_POST['email'];
echo "<br>";
echo $_POST['comment'];
echo "<br>";
	
// Sanitise the text
$firstname = filter_var($_POST['firstname'], FILTER_SANITIZE_STRING);
$surname = filter_var($_POST['surname'], FILTER_SANITIZE_STRING);
$email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);	
$comment = filter_var($_POST['comment'], FILTER_SANITIZE_STRING);

// Make input count the same as the one from the database
$firstname = trimInput($firstname, 50);
$surname = trimInput($surname, 50);
$email = trimInput($email, 50);
$comment = trimInput($comment, 0);

// Update the customer table
$query = "UPDATE customer SET 
		customer_firstname = '$firstname', 
		customer_surname = '$surname',
		customer_email = '$email',
		customer_comment = '$comment'
		WHERE customer_id = {$_SESSION['id']}";

mysqli_query ($con, $query);
?>