<!-- Setting up connections -->
<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";
include "includes/debug.php";
?>
<!-- Start of Booking Page Code -->
<!doctype html>
<html>
<head>
	<title> Website Test </title>
	
	<!-- Main Header -->
	<div class="header">
	  <h1>Adventure</h1>
	</div>
	
	<!-- Viewport and bootstrap code for site -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="../lib/w3.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
	<!-- Styles for website -->
	<style>
	/* Site Body */
	body {
	  font-family: Arial;
	  padding: 10px;
	  background: #f1f1f1;
	}

	/* Puts the Header at the top of the page */
	.header {
	  padding: 30px;
	  text-align: center;
	  background: #ff751a;
	}

	/* Header for Title */
	.header h1 {
	  font-size: 50px;
	}
	
	/* Creates a singular column that spans the whole page */
	.column {
	  float: center;
	  text-align: center;
	  width: 100%;
	  padding: 15px;
	}

	/* Clear floats after the columns */
	.row:after {
	  content: "";
	  display: table;
	  clear: both;
	}
	
	/* Button */
	.button {
	  background-color: white; 
	  color: white; 
	  border: 2px solid black;
	}

	/* Button Hover*/
	.button:hover {
	  background-color: #4CAF50;
	  color: white;
	}

	/* Button Active */
	.active {
	  background-color: #4CAF50;
	}
	
	/* Sets textarea size */
	textarea {
	width: 289px;
	height: 100px;
	}

	</style>
	
	<!-- Script to get/set escaperoom information -->
		<script>
		function er_id(id) {
		  if (id == "") {

		  } else {
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
				var parts = xmlhttp.responseText.split('|');
				document.getElementById("escaperoomname").value = parts[0];
				document.getElementById("er_option").value;
				
				document.getElementById("escaperoomtheme").value = parts[1];
				document.getElementById("er_option").value;
				
				document.getElementById("escaperoomdiff").value = parts[2];
				document.getElementById("er_option").value;
				
				document.getElementById("escaperoomadultprice").value = parts[3];
				document.getElementById("er_option").value;
				
				document.getElementById("escaperoomchildprice").value = parts[4];
				document.getElementById("er_option").value;
				
				document.getElementById("escaperoomsize").value = parts[5];
				document.getElementById("er_option").value;

				document.getElementById("escaperoommaxamount").value = parts[6];
				document.getElementById("er_option").value;
			  }
			};
			xmlhttp.open("GET","escapephp.php?id="+id,true);
			xmlhttp.send();
		  }
		  var xhttp = new XMLHttpRequest();

		}
		</script>
		
		<!-- Script to calculate total price -->
		<script>
		function price_calc() {
		  var adultprice = document.getElementById("escaperoomadultprice").value;
		  var childprice = document.getElementById("escaperoomchildprice").value;
		  var adult = document.getElementById("totaladults").value;
		  var children = document.getElementById("totalchildren").value;
		  var totalpeople = parseInt(adult) + parseInt(children);
		  if (adult == "" || children == "") {

		  } else if (totalpeople > 8) {
			document.getElementById("totalprice").value = "Too many people";
		  } else if (totalpeople <= 8) {
			var total_adult = parseInt(adult) * parseInt(adultprice);
			var total_child = parseInt(children) * parseInt(childprice);
			var price_total = parseInt(total_adult) + parseInt(total_child);
			document.getElementById("totalprice").value = price_total;
		  }
		}
		</script>
</head>
<body class="w3-container">

<!-- Includes navigation -->
<div id="wrapper">
	<nav>
		<?php include "includes/nav.php"; ?>
	</nav>
</div>
<main>
<div class="row">
	<!-- Column for Choose a room / customer information -->
	<div class="column">
		<div class="header">
			<h2>Choose a Room / Customer Information</h2>	
		</div>
		<!-- Display error message -->
		<div id="ErrorMessage">
			<?php
				echo $_SESSION['errorMessage'];
			?>
		</div>
		
		<!-- Form for booking -->
		<div id="bookingcustomerForm">
			<form method="post" action="booking_process.php">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				
				<!-- Displays escape room data -->
				<h4> Escape Room Information </h4>	
				<div class="select-box">
				<label for="escaperoomname">Escape Room:</label>
				<?php
					$query = "SELECT * FROM escape_room";
					$result1 = mysqli_query($con, $query);			
				?>
				<select id="er_option" onchange="er_id(this.value)">
					<option value="" selected disabled>Select a Room</option>
				<?php while ($row = mysqli_fetch_array($result1)):;?>
					<option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
				<?php endwhile;?>

				</select>
				&nbsp;
				<input type="text" name="escaperoomname" id="escaperoomname" value="<?php echo $row['escaperoom_name'];?>">	
				<p></p>
				<label for="escaperoomtheme">Theme:</label>
				&nbsp;
				<input type="text" name="escaperoomtheme" id="escaperoomtheme" value="<?php echo $row['escaperoom_theme']; ?>">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<label for="escaperoomdiff">Difficulty:</label>
				&nbsp;
				<input type="text" name="escaperoomdiff" id="escaperoomdiff" value="<?php echo $row['escaperoom_difficulty']; ?>">
				<p></p>
				<label for="escaperoomadultprice">Adult Price:</label>
				&nbsp;
				<input type="text" name="escaperoomadultprice" id="escaperoomadultprice" value="<?php echo $row['escaperoom_adult_price']; ?>">
				&nbsp;&nbsp;&nbsp;&nbsp;
				<label for="escaperoomchildprice">Child Price:</label>
				&nbsp;
				<input type="text" name="escaperoomchildprice" id="escaperoomchildprice" value="<?php echo $row['escaperoom_child_price']; ?>">
				<p></p>
				<label for="escaperoomsize">Room Size:</label>
				&nbsp;
				<input type="text" name="escaperoomsize" id="escaperoomsize" value="<?php echo $row['escaperoom_size']; ?>">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<label for="escaperoommaxamount">Max Player Amount:</label>
				&nbsp;
				<input type="text" name="escaperoommaxamount" id="escaperoommaxamount" value="<?php echo $row['escaperoom_playeramount']; ?>">								
				</div>
				<p></p>
				<label for="totaladults">How many adults?</label>
				<input type="" name="totaladults" id="totaladults" onkeyup="price_calc()">
				<label for="totalchildren">How many children?</label>
				<input type="text" name="totalchildren" id="totalchildren" onkeyup="price_calc()">					
				<label for="totalprice">Total Price:</label>
				<input type="text" name="totalprice" id="totalprice" value="<?php echo $result ?>">
				<br></br><br></br>

				<!-- Displays customer data -->
				<h4> Customer Information </h4>			
				<?php
					if ($_SESSION['loggedin']) {	

					$query = "SELECT customer_firstname, customer_surname, customer_email, customer_phone, customer_comment from customer WHERE customer_id = {$_SESSION['id']}";
									
					$result2 = mysqli_query ($con, $query);
									
					$row = mysqli_fetch_array ($result2);
									
					} else {
						header ("Location: index.php");
					}
				?>
				<label for="firstname">Your Firstname:</label>
				&nbsp;
				<input type="text" name="firstname" id="firstname" value="<?php echo $row['customer_firstname']; ?>">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<label for="surname">Your Surname:</label>
				&nbsp;
				<input type="text" name="surname" id="surname" value="<?php echo $row['customer_surname']; ?>">
				<p></p>
				<label for="email">Your email:</label>
				&nbsp;
				<input type="email" name="email" id="email" value="<?php echo $row['customer_email']; ?>">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<label for="phone">Your Phone:</label>
				&nbsp;
				<input type="phone" name="phone" id="phone" value="<?php echo $row['customer_phone']; ?>">
				<p></p>
				<label for="comment">Comment:</label>
				<p></p>
				<textarea name="comment" id="comment"><?php echo $row['customer_comment']; ?></textarea>
				<br></br>
				<input type="submit" name="submit" value="Make Booking">
			</form>
		</div>
	</div>
</div>
</main>

<!-- Includes Footer -->
<div id="wrapper">
	<footer>
		<?php include "includes/footer.php"; ?>
	</footer>
</div> <!-- End of Wrapper -->
</body>
</html>