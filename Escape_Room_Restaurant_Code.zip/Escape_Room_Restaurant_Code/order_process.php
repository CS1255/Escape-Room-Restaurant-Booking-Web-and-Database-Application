<?php
// start session, connect to database
session_start();
include "includes/connect.php";
$_SESSION['errorMessage'] = "";

// Stores the data from the form for later use
$_SESSION['foodname'] = $_POST['foodname'];
$_SESSION['foodprice'] = $_POST['foodprice'];
$_SESSION['foodtype'] = $_POST['foodtype'];

$_SESSION['firstname'] = $_POST['firstname'];
$_SESSION['surname'] = $_POST['surname'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['phone'] = $_POST['phone'];

// Checks if food fields are empty
if ($_POST['foodname'] == "") $_SESSION['errorMessage'] .= "<p>Please choose some food</p>";
if ($_POST['foodprice'] == "") $_SESSION['errorMessage'] .= "<p>Please choose some food</p>";
if ($_POST['foodtype'] == "") $_SESSION['errorMessage'] .= "<p>Please choose some food</p>";

// Data labels made from form input
$food_name = $_POST['foodname'];
$food_price = $_POST['foodprice'];
$food_type = $_POST['foodtype'];
		
$custFirstname = $_POST['firstname'];
$custSurname = $_POST['surname'];
$custEmail = $_POST['email'];
$custPhone = $_POST['phone'];

// INSERT query to add order
$query = "INSERT INTO orders_list(custOrder_firstName, custOrder_surName, custOrder_email, custOrder_phone, custOrder_foodName, custOrder_foodType, custOrder_foodPrice) values('$custFirstname', '$custSurname', '$custEmail', '$custPhone', '$food_name', '$food_type', '$food_price')";

//Checks to see if order was successful or not.
if (mysqli_query($con, $query)) {
	//If successful, echo this message.
	echo "Order successful";
}
else {
	//If failed, echo this message and display query.
	echo "Order failed: " . $query . "<br>" . mysqli_error($con);
}
?>