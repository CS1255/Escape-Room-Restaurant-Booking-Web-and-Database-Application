<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";
include "includes/debug.php";

//Gets the food ID through a value.
$id = $_REQUEST["id"];
$query = "SELECT * FROM food WHERE food_id=".$id;
$result = mysqli_query($con, $query);	
$row = mysqli_fetch_array($result);

//Turns data into values based on ID.
$food_name = $row["food_name"];
$food_price = $row["food_price"];
$food_type = $row["food_type"];

//Echos the data.
echo "$food_name|$food_price|$food_type";
?>