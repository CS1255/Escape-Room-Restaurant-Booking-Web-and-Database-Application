<!-- Setting up connections -->
<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";
include "includes/debug.php";
?>
<!-- Start of Home Page Code -->
<!doctype html>
<html>
<head>
	<title> Website Test </title>
	
	<!-- Main Header -->
	<div class="header">
	  <h1>Adventure</h1>
	</div>
	
	<!-- Viewport and bootstrap code for site -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
	<!-- Styles for website -->
	<style>
	/* Site Body */
	body {
	  font-family: Arial;
	  padding: 10px;
	  background: #f1f1f1;
	}

	/* Header/Blog Title */
	.header {
	  padding: 30px;
	  text-align: center;
	  background: #ff751a;
	}

	/* Header for Title */
	.header h1 {
	  font-size: 50px;
	}
		
	/* Create three equal columns that floats next to each other */
	.column {
	  float: left;
	  width: 50%;
	  padding: 15px;
	}

	/* Clear floats after the columns */
	.row:after {
	  content: "";
	  display: table;
	  clear: both;
	}
	</style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50">

<!-- Includes navigation -->
<div id="wrapper">
	<nav>
		<?php include "includes/nav.php"; ?>
	</nav>
</div>
<main>
<div class="row">
	<!-- Column for carousel -->
	<div class="column">
		<div id="myCarousel" class="carousel slide" data-ride="carousel">
		<!-- Indicators for carousel -->
		<ol><a class="carousel-indicators">
			<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
			<li data-target="#myCarousel" data-slide-to="1"></li>
			<li data-target="#myCarousel" data-slide-to="2"></li>
		</a></ol>

		<!-- Wrapper for slides -->
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="escaperoomimages/HedgeMaze.jpg" alt="New York" width="1200" height="700">
				<div class="carousel-caption">
					<h3>Answer the call!</h3>
					<p>Experience adventure like no other!</p>
				</div>      
			</div>

			<div class="item">
				<img src="escaperoomimages/SpyMission.jpg" alt="spymission" width="1200" height="700">
				<div class="carousel-caption">
					<h3>Do you dare?</h3>
					<p>Can you solve the puzzles and escape before time runs out? These rooms will test your adventuring skills!</p>
				</div>      
			</div>
				
			<div class="item">
				<img src="escaperoomimages/cafeteria.jpeg" alt="cafe" width="1200" height="700">
				<div class="carousel-caption">
					<h3>Want a bite?</h3>
					<p>Even adventurers need something to eat after their journey! Check out our restaurant!</p>
				</div>      
			</div>
		</div>

			<!-- Left and right controls -->
			<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
	</div>

	<!-- Column for About Us -->
	<div class="column">
		<div class="header">
			<h2>About Us</h2>
		</div>
		<p></p>
		<p>Welcome to ADVENTURE! Here at our establishment, you can experience numerous adventures from being pirates to secret agents, to exploring an ancient tomb or navigating a spaceship. These adventures will challenge your mind and speed as you'll solve puzzles in a time limit of just one hour! </p>
		<p>After you've experienced your journey, your body and mind will be tired out so why not restore your energy at our restaurant! Every adventurer needs a place to relaxe and a bite to eat after all, of course you can also dine in before you begin your quest to prepare for whats ahead!</p>
	</div> 
</div>
</main>

<!-- Includes Footer -->
<div id="wrapper">
	<footer>
		<?php include "includes/footer.php"; ?>
	</footer>
</div> <!-- End of Wrapper -->


</body>
</html>
<!-- End of Home Page code -->