<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";
include "includes/debug.php";

//Gets the escape room ID through a value.
$id = $_REQUEST["id"];
$query = "SELECT * FROM escape_room WHERE escaperoom_id=".$id;
$result = mysqli_query($con, $query);	
$row = mysqli_fetch_array($result);

//Turns data into values based on ID.
$room_name = $row["escaperoom_name"];
$room_theme = $row["escaperoom_theme"];
$room_diff = $row["escaperoom_difficulty"];
$room_adulprice = $row["escaperoom_adult_price"];
$room_chilprice = $row["escaperoom_child_price"];
$room_size = $row["escaperoom_size"];
$room_playamoun = $row["escaperoom_playeramount"];

//Echos the data.
echo "$room_name|$room_theme|$room_diff|$room_adulprice|$room_chilprice|$room_size|$room_playamoun";
?>