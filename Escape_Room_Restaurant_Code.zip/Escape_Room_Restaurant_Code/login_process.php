<?php
// start session, connect to database
session_start();
include "includes/connect.php";

// Default is no value
$_SESSION['loggedin'] = false;
$_SESSION['id'] = 0;

// Checks if username/password textfields are empty
if ($_POST['username'] != "" and $_POST['password'] != "") {

	// Query checks to see if the username from the form and database match
	$query = "SELECT customer_id, customer_password FROM customer WHERE customer_username = '{$_POST['username']}'";
	$result = mysqli_query ($con, $query);
	$row = mysqli_fetch_array ($result);


	// If the password from the form and the database match
	if ($row['customer_password'] == $_POST['password']) {
		// log the user in
		$_SESSION['loggedin'] = true;
		$_SESSION['id'] = $row['customer_id'];
	} else {
		// make sure the user is not logged in
		$_SESSION['loggedin'] = false;
		$_SESSION['id'] = 0;
	}
	
}

header("Location: index.php");
?>