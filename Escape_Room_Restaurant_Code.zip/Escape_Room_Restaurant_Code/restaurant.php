<!-- Setting up connections -->
<?php
// start session, connect to database
session_start();
include "includes/connect.php";
include "includes/functions.php";
include "includes/debug.php";
?>
<!-- Start of Restaurant Page Code -->
<!doctype html>
<html>
<head>
	<title> Website Test </title>
	
	<!-- Main Header -->
	<div class="header">
	  <h1>Adventure</h1>
	</div>
	
	<!-- Viewport and bootstrap code for site -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		
	<!-- Styles for website -->
	<style>
	/* Site Body */
	body {
	  font-family: Arial;
	  padding: 10px;
	  background: #f1f1f1;
	}

	/* Header/Blog Title */
	.header {
	  padding: 30px;
	  text-align: center;
	  background: #ff751a;
	}

	/* Header for Title */
	.header h1 {
	  font-size: 50px;
	}
	
	/* Centers header in columns */
	.header2 {
	  padding: 30px;
	  text-align: center;
	  background: #0066cc;
	  color: white;
	}
	
	/* Image settings */
	img {
	  float: left;
	  position: static;
	}
	
	/* restaurant modal */
	#restaurant {
	  width: 750px;
	  padding: 50px;
	  margin: 10px;
	}
	
	/* Creates a singular column that spans the whole page */
	.column {
	  float: center;
	  text-align: left;
	  width: 100%;
	  padding: 15px;
	}
	
	/* Creates a singular column that spans the whole page */
	.column2 {
	  float: left;
	  text-align: left;
	  width: 50%;
	  padding: 15px;
	}

	/* Clear floats after the columns */
	.row:after {
	  content: "";
	  display: table;
	  clear: both;
	}

	/* Gallery settings */
	div.gallery {
	  margin: 50px;
	  border: 1px solid #0066cc;
	  float: left;
	  width: 200px;
	  height: 275px;
	}

	/* When hovering over gallery */
	div.gallery:hover {
	  border: 1px solid #0066cc;
	}

	/* Gallery image settings */
	div.gallery img {
	  width: 100%;
	  height: auto;
	}

	/* Gallery description */
	div.desc {
	  padding: 15px;
	  text-align: center;
	}
	</style>
</head>
<body>

<!-- Includes navigation -->
<div id="wrapper">
	<nav>
		<?php include "includes/nav.php"; ?>
	</nav>
</div>

<main>
<div class="row">
	<!-- Column for restaurant food list -->
	<div class="column">
		<div class="header">
			<h2>Our Restaurant</h2>
		</div>
	<div class="row">
		<!-- Burger Column -->
		<div class="column2">
			<div class="header2">
				<h2>Burgers</h2>
			</div>
			
			<!-- Cheese Burger Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Burgers/CheeseBurger.jpg" alt="CheeseBurger" width="600" height="400" />
			  </a>
			  <div class="desc">Cheese Burger<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal1">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal1" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Cheese Burger</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Burgers/CheeseBurger.jpg" style="width:170px;height:170px;margin-right:10px;" alt="CheeseBurger" />
									<?php 
									echo $_SESSION['food_id'] = "1.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 1";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>

			<!-- Ham Burger Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Burgers/hamburger.jpg" alt="hamburger" width="600" height="400" />
			  </a>
			  <div class="desc">Ham Burger<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal2">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal2" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Ham Burger</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Burgers/hamburger.jpg" style="width:170px;height:170px;margin-right:10px;" alt="hamburger" />
									<?php 
									echo $_SESSION['food_id'] = "2.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 2";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>

			<!-- Chicken Burger Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Burgers/chickenburger.jpg" alt="chickenburger" width="600" height="400" />
			  </a>
			  <div class="desc">Chicken Burger<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal3">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal3" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Chicken Burger</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Burgers/chickenburger.jpg" style="width:170px;height:170px;margin-right:10px;" alt="chickenburger" />
									<?php 
									echo $_SESSION['food_id'] = "3.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 3";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>

			<!-- Cheese and Bacon Burger Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Burgers/cheesebaconburger.jpg" alt="cheesebaconburger" width="600" height="400" />
			  </a>
			  <div class="desc">Cheese and Bacon Burger<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal4">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal4" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Cheese and Bacon Burger</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Burgers/cheesebaconburger.jpg" style="width:170px;height:170px;margin-right:10px;" alt="cheesebaconburger" />
									<?php 
									echo $_SESSION['food_id'] = "4.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 4";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>

			<!-- Vegan Burger Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Burgers/veganburger.jpg" alt="veganburger" width="600" height="400" />
			  </a>
			  <div class="desc">Vegan Burger<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal5">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal5" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Vegan Burger</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Burgers/veganburger.jpg" style="width:170px;height:170px;margin-right:10px;" alt="veganburger" />
									<?php 
									echo $_SESSION['food_id'] = "5.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 5";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>			
		</div>

		<!-- Sandwich Column -->			
		<div class="column2">
			<div class="header2">
				<h2>Sandwiches</h2>
			</div>
			<!-- Cheese Sandwich Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sandwich/cheesesandwich.jpg" alt="cheesesandwich" width="600" height="400" />
			  </a>
			  <div class="desc">Cheese Sandwich<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal6">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal6" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Cheese Sandwich</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sandwich/cheesesandwich.jpg" style="width:170px;height:170px;margin-right:10px;" alt="cheesesandwich" />
									<?php 
									echo $_SESSION['food_id'] = "6.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 6";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Ham Sandwich Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sandwich/hamsandwich.jpg" alt="hamsandwich" width="600" height="400" />
			  </a>
			  <div class="desc">Ham Sandwich<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal7">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal7" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Ham Sandwich</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sandwich/hamsandwich.jpg" style="width:170px;height:170px;margin-right:10px;" alt="hamsandwich" />
									<?php 
									echo $_SESSION['food_id'] = "7.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 7";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Chicken Sandwich Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sandwich/chickensandwich.jpg" alt="chickensandwich" width="600" height="400" />
			  </a>
			  <div class="desc">Chicken Sandwich<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal8">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal8" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Chicken Sandwich</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sandwich/chickensandwich.jpg" style="width:170px;height:170px;margin-right:10px;" alt="chickensandwich" />
									<?php 
									echo $_SESSION['food_id'] = "8.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 8";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Egg and Mayo Sandwich Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sandwich/eggmayosandwich.jpg" alt="eggmayosandwich" width="600" height="400" />
			  </a>
			  <div class="desc">Egg and Mayo Sandwich<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal9">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal9" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Egg and Mayo Sandwich</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sandwich/eggmayosandwich.jpg" style="width:170px;height:170px;margin-right:10px;" alt="eggmayosandwich" />
									<?php 
									echo $_SESSION['food_id'] = "9.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 9";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Vegan Sandwich Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sandwich/vegansandwich.jpg" alt="vegansandwich" width="600" height="400" />
			  </a>
			  <div class="desc">Vegan Sandwich<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal10">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal10" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Vegan Sandwich</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sandwich/vegansandwich.jpg" style="width:170px;height:170px;margin-right:10px;" alt="vegansandwich" />
									<?php 
									echo $_SESSION['food_id'] = "10.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 10";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
		</div>
		
		<!-- Pizza Column -->
		<div class="column2">
			<div class="header2">
				<h2>Pizzas</h2>
			</div>
			<!-- Cheese Pizza Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Pizza/cheesepizza.jpg" alt="cheesepizza" width="600" height="400" />
			  </a>
			  <div class="desc">Cheese Pizza<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal11">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal11" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Cheese Pizza</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Pizza/cheesepizza.jpg" style="width:170px;height:170px;margin-right:10px;" alt="cheesepizza" />
									<?php 
									echo $_SESSION['food_id'] = "11.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 11";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Cheese and Bacon Pizza Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Pizza/baconpizza.jpg" alt="baconpizza" width="600" height="400" />
			  </a>
			  <div class="desc">Cheese and Bacon Pizza<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal12">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal12" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Cheese and Bacon Pizza</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Pizza/baconpizza.jpg" style="width:170px;height:170px;margin-right:10px;" alt="baconpizza" />
									<?php 
									echo $_SESSION['food_id'] = "12.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 12";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Pepperoni Pizza Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Pizza/pepperonipizza.jpg" alt="pepperonipizza" width="600" height="400" />
			  </a>
			  <div class="desc">Pepperoni Pizza<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal13">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal13" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Pepperoni Pizza</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Pizza/pepperonipizza.jpg" style="width:170px;height:170px;margin-right:10px;" alt="pepperonipizza" />
									<?php 
									echo $_SESSION['food_id'] = "13.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 13";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Spicy Pizza Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Pizza/spicypizza.jpg" alt="spicypizza" width="600" height="400" />
			  </a>
			  <div class="desc">Spicy Pizza<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal14">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal14" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Spicy Pizza</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Pizza/spicypizza.jpg" style="width:170px;height:170px;margin-right:10px;" alt="spicypizza" />
									<?php 
									echo $_SESSION['food_id'] = "14.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 14";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Vegan Pizza Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Pizza/veganpizza.jpg" alt="veganpizza" width="600" height="400" />
			  </a>
			  <div class="desc">Vegan Pizza<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal15">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal15" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Vegan Pizza</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Pizza/veganpizza.jpg" style="width:170px;height:170px;margin-right:10px;" alt="veganpizza" />
									<?php 
									echo $_SESSION['food_id'] = "15.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 15";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
		</div>
		
		<!-- Sides Column -->
		<div class="column2">
			<div class="header2">
				<h2>Sides</h2>
			</div>
			<!-- Chips Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sides/chips.jpg" alt="chips" width="600" height="400" />
			  </a>
			  <div class="desc">Chips<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal16">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal16" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Chips</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sides/chips.jpg" style="width:170px;height:170px;margin-right:10px;" alt="chips" />
									<?php 
									echo $_SESSION['food_id'] = "16.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 16";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Garlic Bread Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sides/garlicbread.jpg" alt="garlicbread" width="600" height="400" />
			  </a>
			  <div class="desc">Garlic Bread<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal17">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal17" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Garlic Bread</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sides/garlicbread.jpg" style="width:170px;height:170px;margin-right:10px;" alt="garlicbread" />
									<?php 
									echo $_SESSION['food_id'] = "17.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 17";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Fruit Salad Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sides/fruitsalad.jpg" alt="fruitsalad" width="600" height="400" />
			  </a>
			  <div class="desc">Fruit Salad<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal18">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal18" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Fruit Salad</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sides/fruitsalad.jpg" style="width:170px;height:170px;margin-right:10px;" alt="fruitsalad" />
									<?php 
									echo $_SESSION['food_id'] = "18.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 18";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Chicken Bites Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sides/chickenbites.jpg" alt="chickenbites" width="600" height="400" />
			  </a>
			  <div class="desc">Chicken Bites<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal19">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal19" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Chicken Bites</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sides/chickenbites.jpg" style="width:170px;height:170px;margin-right:10px;" alt="chickenbites" />
									<?php 
									echo $_SESSION['food_id'] = "19.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 19";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Mozzarella Bites Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sides/mozzarellabites.jpg" alt="mozzarellabites" width="600" height="400" />
			  </a>
			  <div class="desc">Mozzarella Bites<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal20">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal20" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Mozzarella Bites</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sides/mozzarellabites.jpg" style="width:170px;height:170px;margin-right:10px;" alt="mozzarellabites" />
									<?php 
									echo $_SESSION['food_id'] = "20.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 20";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Crisps Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Sides/crisps.jpg" alt="crisps" width="600" height="400" />
			  </a>
			  <div class="desc">Crisps<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal21">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal21" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Crisps</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Sides/crisps.jpg" style="width:170px;height:170px;margin-right:10px;" alt="crisps" />
									<?php 
									echo $_SESSION['food_id'] = "21.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 21";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
		</div>
		
		<!-- Drinks Column -->
		<div class="column2">
			<div class="header2">
				<h2>Drinks</h2>
			</div>
			<!-- Coca Cola Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/cocacola.jpg" alt="cocacola" width="600" height="400" />
			  </a>
			  <div class="desc">Coca Cola<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal22">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal22" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Coca Cola</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/cocacola.jpg" style="width:170px;height:170px;margin-right:10px;" alt="cocacola" />
									<?php 
									echo $_SESSION['food_id'] = "22.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 22";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Diet Coke Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/dietcoke.jpg" alt="dietcoke" width="600" height="400" />
			  </a>
			  <div class="desc">Diet Coke<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal23">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal23" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Diet Coke</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/dietcoke.jpg" style="width:170px;height:170px;margin-right:10px;" alt="dietcoke" />
									<?php 
									echo $_SESSION['food_id'] = "23.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 23";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Zero Coke Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/cokezero.jpg" alt="cokezero" width="600" height="400" />
			  </a>
			  <div class="desc">Zero Coke<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal24">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal24" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Zero Coke</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/cokezero.jpg" style="width:170px;height:170px;margin-right:10px;" alt="cokezero" />
									<?php 
									echo $_SESSION['food_id'] = "24.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 24";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Water Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/water.jpg" alt="water" width="600" height="400" />
			  </a>
			  <div class="desc">Water<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal25">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal25" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Water</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/water.jpg" style="width:170px;height:170px;margin-right:10px;" alt="water" />
									<?php 
									echo $_SESSION['food_id'] = "25.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 25";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Strawberry Flavoured Water Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/strawberrywater.jpg" alt="strawberrywater" width="600" height="400" />
			  </a>
			  <div class="desc">Strawberry Flavoured Water<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal26">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal26" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Strawberry Flavoured Water</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/strawberrywater.jpg" style="width:170px;height:170px;margin-right:10px;" alt="strawberrywater" />
									<?php 
									echo $_SESSION['food_id'] = "26.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 26";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Lemon Flavoured Water Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/lemonwater.jpg" alt="lemonwater" width="600" height="400" />
			  </a>
			  <div class="desc">Lemon Flavoured Water<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal27">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal27" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Lemon Flavoured Water</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/lemonwater.jpg" style="width:170px;height:170px;margin-right:10px;" alt="lemonwater" />
									<?php 
									echo $_SESSION['food_id'] = "27.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 27";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Grape Flavoured Water Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/grapewater.jpeg" alt="grapewater" width="600" height="400" />
			  </a>
			  <div class="desc">Grape Flavoured Water<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal28">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal28" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Grape Flavoured Water</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/grapewater.jpeg" style="width:170px;height:170px;margin-right:10px;" alt="grapewater" />
									<?php 
									echo $_SESSION['food_id'] = "28.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 28";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Apple Flavoured Water Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/applewater.jpg" alt="applewater" width="600" height="400" />
			  </a>
			  <div class="desc">Apple Flavoured Water<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal29">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal29" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Apple Flavoured Water</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/applewater.jpg" style="width:170px;height:170px;margin-right:10px;" alt="applewater" />
									<?php 
									echo $_SESSION['food_id'] = "29.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 29";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Apple Juice Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/applejuice.png" alt="applejuice" width="600" height="400" />
			  </a>
			  <div class="desc">Apple Juice<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal30">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal30" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Apple Juice</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/applejuice.png" style="width:170px;height:170px;margin-right:10px;" alt="applejuice" />
									<?php 
									echo $_SESSION['food_id'] = "30.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 30";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Lemonade Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/lemonade.jpg" alt="lemonade" width="600" height="400" />
			  </a>
			  <div class="desc">Lemonade<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal31">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal31" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Lemonade</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/lemonade.jpg" style="width:170px;height:170px;margin-right:10px;" alt="lemonade" />
									<?php 
									echo $_SESSION['food_id'] = "31.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 31";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Orange Juice Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/orangejuice.jpg" alt="orangejuice" width="600" height="400" />
			  </a>
			  <div class="desc">Orange Juice<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal32">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal32" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Orange Juice</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/orangejuice.jpg" style="width:170px;height:170px;margin-right:10px;" alt="orangejuice" />
									<?php 
									echo $_SESSION['food_id'] = "32.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 32";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Milk Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/milk.jpg" alt="milk" width="600" height="400" />
			  </a>
			  <div class="desc">Milk<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal33">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal33" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Milk</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/milk.jpg" style="width:170px;height:170px;margin-right:10px;" alt="milk" />
									<?php 
									echo $_SESSION['food_id'] = "33.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 33";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Strawberry Flavoured Milk Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/strawberrymilk.jpg" alt="strawberrymilk" width="600" height="400" />
			  </a>
			  <div class="desc">Strawberry Flavoured Milk<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal34">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal34" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Strawberry Flavoured Milk</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/strawberrymilk.jpg" style="width:170px;height:170px;margin-right:10px;" alt="strawberrymilk" />
									<?php 
									echo $_SESSION['food_id'] = "34.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 34";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Chocolate Flavoured Milk Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/chocolatemilk.jpg" alt="chocolatemilk" width="600" height="400" />
			  </a>
			  <div class="desc">Chocolate Flavoured Milk<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal35">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal35" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Chocolate Flavoured Milk</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/chocolatemilk.jpg" style="width:170px;height:170px;margin-right:10px;" alt="chocolatemilk" />
									<?php 
									echo $_SESSION['food_id'] = "35.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 35";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Banana Flavoured Milk Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/bananamilk.jpg" alt="bananamilk" width="600" height="400" />
			  </a>
			  <div class="desc">Banana Flavoured Milk<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal36">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal36" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Banana Flavoured Milk</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/bananamilk.jpg" style="width:170px;height:170px;margin-right:10px;" alt="bananamilk" />
									<?php 
									echo $_SESSION['food_id'] = "36.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 36";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Tea -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/tea.jpg" alt="tea" width="600" height="400" />
			  </a>
			  <div class="desc">Tea<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal37">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal37" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Tea</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/tea.jpg" style="width:170px;height:170px;margin-right:10px;" alt="tea" />
									<?php 
									echo $_SESSION['food_id'] = "37.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 37";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Coffee -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Drinks/coffee.jpg" alt="coffee" width="600" height="400" />
			  </a>
			  <div class="desc">Coffee<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal38">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal38" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Coffee</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Drinks/coffee.jpg" style="width:170px;height:170px;margin-right:10px;" alt="coffee" />
									<?php 
									echo $_SESSION['food_id'] = "38.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 38";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
		</div>
		
		<!-- Deserts Column -->
		<div class="column2">
			<div class="header2">
				<h2>Deserts</h2>
			</div>
			<!-- Chocolate Icecream Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/chocolateicecream.jpg" alt="chocolateicecream" width="600" height="400" />
			  </a>
			  <div class="desc">Chocolate Icecream<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal39">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal39" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Chocolate Icecream</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/chocolateicecream.jpg" style="width:170px;height:170px;margin-right:10px;" alt="chocolateicecream" />
									<?php 
									echo $_SESSION['food_id'] = "39.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 39";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Vanilla Icecream Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/vanillaicecream.jpg" alt="vanillaicecream" width="600" height="400" />
			  </a>
			  <div class="desc">Vanilla Icecream<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal40">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal40" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Vanilla Icecream</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/vanillaicecream.jpg" style="width:170px;height:170px;margin-right:10px;" alt="vanillaicecream" />
									<?php 
									echo $_SESSION['food_id'] = "40.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 40";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Mint Icecream Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/minticecream.jpg" alt="minticecream" width="600" height="400" />
			  </a>
			  <div class="desc">Mint Icecream<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal41">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal41" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Mint Icecream</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/minticecream.jpg" style="width:170px;height:170px;margin-right:10px;" alt="minticecream" />
									<?php 
									echo $_SESSION['food_id'] = "41.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 41";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Strawberry Icecream Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/strawberryicecream.jpg" alt="strawberryicecream" width="600" height="400" />
			  </a>
			  <div class="desc">Strawberry Icecream<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal42">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal42" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Strawberry Icecream</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/strawberryicecream.jpg" style="width:170px;height:170px;margin-right:10px;" alt="strawberryicecream" />
									<?php 
									echo $_SESSION['food_id'] = "42.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 42";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Chocolate Cake Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/chocolatecake.jpg" alt="chocolatecake" width="600" height="400" />
			  </a>
			  <div class="desc">Chocolate Cake<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal43">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal43" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Chocolate Cake</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/chocolatecake.jpg" style="width:170px;height:170px;margin-right:10px;" alt="chocolatecake" />
									<?php 
									echo $_SESSION['food_id'] = "43.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 43";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Victoria Sponge Cake Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/victoriasponge.jpg" alt="victoriasponge" width="600" height="400" />
			  </a>
			  <div class="desc">Victoria Sponge Cake<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal44">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal44" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Victoria Sponge Cake</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/victoriasponge.jpg" style="width:170px;height:170px;margin-right:10px;" alt="victoriasponge" />
									<?php 
									echo $_SESSION['food_id'] = "44.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 44";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Lemon Cake Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/lemoncake.jpg" alt="lemoncake" width="600" height="400" />
			  </a>
			  <div class="desc">Lemon Cake<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal45">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal45" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Lemon Cake</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/lemoncake.jpg" style="width:170px;height:170px;margin-right:10px;" alt="lemoncake" />
									<?php 
									echo $_SESSION['food_id'] = "45.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 45";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Coconut Cake Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/coconutcake.jpg" alt="coconutcake" width="600" height="400" />
			  </a>
			  <div class="desc">Coconut Cake<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal46">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal46" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Coconut Cake</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/coconutcake.jpg" style="width:170px;height:170px;margin-right:10px;" alt="coconutcake" />
									<?php 
									echo $_SESSION['food_id'] = "46.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 46";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Chocolate Milkshake Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/chocolatemilkshake.jpg" alt="chocolatemilkshake" width="600" height="400" />
			  </a>
			  <div class="desc">Chocolate Milkshake<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal47">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal47" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Chocolate Milkshake</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/chocolatemilkshake.jpg" style="width:170px;height:170px;margin-right:10px;" alt="chocolatemilkshake" />
									<?php 
									echo $_SESSION['food_id'] = "47.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 47";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Strawberry Milkshake Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/strawberrymilkshake.jpg" alt="strawberrymilkshake" width="600" height="400" />
			  </a>
			  <div class="desc">Strawberry Milkshake<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal48">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal48" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Strawberry Milkshake</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/strawberrymilkshake.jpg" style="width:170px;height:170px;margin-right:10px;" alt="strawberrymilkshake" />
									<?php 
									echo $_SESSION['food_id'] = "48.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 48";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Banana Milkshake Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/bananamilkshake.jpg" alt="bananamilkshake" width="600" height="400" />
			  </a>
			  <div class="desc">Banana Milkshake<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal49">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal49" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Banana Milkshake</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/bananamilkshake.jpg" style="width:170px;height:170px;margin-right:10px;" alt="bananamilkshake" />
									<?php 
									echo $_SESSION['food_id'] = "49.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 49";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Jelly Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/jelly.jpg" alt="jelly" width="600" height="400" />
			  </a>
			  <div class="desc">Jelly<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal50">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal50" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Jelly</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/jelly.jpg" style="width:170px;height:170px;margin-right:10px;" alt="jelly" />
									<?php 
									echo $_SESSION['food_id'] = "50.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 50";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Chocolate Fudge Brownies (With Sauce) Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/chocfudgebrownie.jpg" alt="chocfudgebrownie" width="600" height="400" />
			  </a>
			  <div class="desc">Chocolate Fudge Brownies (With Sauce)<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal51">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal51" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Chocolate Fudge Brownies (With Sauce)</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/chocfudgebrownie.jpg" style="width:170px;height:170px;margin-right:10px;" alt="chocfudgebrownie" />
									<?php 
									echo $_SESSION['food_id'] = "51.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 51";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
			
			<!-- Cookies Modal -->
			<div class="gallery">
			  <a target="_blank">
				<img src="restaurantimages/Desert/chocchipcookies.jpg" alt="chocchipcookies" width="600" height="400" />
			  </a>
			  <div class="desc">Cookies<p></p><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal52">Learn more!</button></div>
			  <!-- Modal -->
			  <div class="modal fade" id="myModal52" role="dialog">
				<div class="modal-dialog modal-lg">
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Cookies</h4>
					</div>
					<div class="modal-body">
						<div id="restaurant">
							<form method="post" action="">
								<div class ="container">
									<img src="restaurantimages/Desert/chocchipcookies.jpg" style="width:170px;height:170px;margin-right:10px;" alt="chocchipcookies" />
									<?php 
									echo $_SESSION['food_id'] = "52.";
									$query = "SELECT food_name, food_price, food_type FROM food WHERE food_id = 52";
									$result = mysqli_query ($con, $query);
									$row = mysqli_fetch_array ($result);
									?>
										<label for="foodname">Food Name:</label>
										<input type="text" name="foodname" id="foodname" value="<?php echo $row['food_name'];?>">
										<label for="foodprice">Food Price:</label>
										<input type="text" name="foodprice" id="foodprice" value="<?php echo $row['food_price']; ?>">
										<p></p>
										<label for="foodtype">Food Type:</label>
										<input type="text" name="foodtype" id="foodtype" value="<?php echo $row['food_type']; ?>">
										<?php
											if ($_SESSION['loggedin']) {
												echo "<button class=\"button button1\"><a href=\"makeorder.php\">Order this food?</a></button> <!-- Only when logged in -->";
											}
										?>
								</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>   
			</div>
		</div>
	</div>
	</div> 
</div>
</main>

<!-- Includes Footer -->
<div id="wrapper">
	<footer>
		<?php include "includes/footer.php"; ?>
	</footer>
</div>

</body>
</html>